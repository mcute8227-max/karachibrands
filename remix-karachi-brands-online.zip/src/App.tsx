import React from 'react';
import { StoreProvider } from './context/StoreContext';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { BrandBar } from './components/BrandBar';
import { ProductCatalog } from './components/ProductCatalog';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { AdminDashboard } from './components/AdminDashboard';
import { Footer } from './components/Footer';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';

export default function App() {
  return (
    <StoreProvider>
      <div className="min-h-screen flex flex-col bg-neutral-50 font-body text-neutral-900">
        
        {/* Navigation Bar */}
        <Navbar />

        {/* Main Content Area */}
        <main className="flex-1">
          {/* Hero Campaign Banner */}
          <HeroBanner />

          {/* Designer Brand Filter Strip */}
          <BrandBar />

          {/* Comprehensive Unstitched Product Catalog */}
          <ProductCatalog />
        </main>

        {/* Brand Footer */}
        <Footer />

        {/* Modals & Overlays */}
        <ProductModal />
        <CartDrawer />
        <CheckoutModal />
        <OrderTrackingModal />
        <AdminDashboard />

        {/* Direct WhatsApp Helper */}
        <WhatsAppFloatingButton />

      </div>
    </StoreProvider>
  );
}
