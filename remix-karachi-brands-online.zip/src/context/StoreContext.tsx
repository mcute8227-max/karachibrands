import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CustomerOrder, StoreConfig, CartItem, CurrencyCode } from '../types';
import { INITIAL_PRODUCTS, INITIAL_ORDERS, DEFAULT_STORE_CONFIG, CURRENCY_RATES } from '../data/initialData';

interface StoreContextType {
  products: Product[];
  orders: CustomerOrder[];
  storeConfig: StoreConfig;
  cart: CartItem[];
  wishlist: string[];
  activeCurrency: CurrencyCode;
  isAdminLoggedIn: boolean;
  
  // UI Modals
  isCartOpen: boolean;
  isCheckoutOpen: boolean;
  isAdminDashboardOpen: boolean;
  isOrderTrackingOpen: boolean;
  selectedProduct: Product | null;
  activeCategory: string;
  selectedBrand: string;
  searchQuery: string;
  defaultPaymentMethod: 'COD' | 'Card' | 'JazzCash' | 'EasyPaisa' | 'BankTransfer' | 'WhatsApp';

  // Actions
  setCartOpen: (open: boolean) => void;
  setCheckoutOpen: (open: boolean) => void;
  setAdminDashboardOpen: (open: boolean) => void;
  setOrderTrackingOpen: (open: boolean) => void;
  setSelectedProduct: (product: Product | null) => void;
  setActiveCategory: (cat: string) => void;
  setSelectedBrand: (brand: string) => void;
  setSearchQuery: (query: string) => void;
  setCurrency: (code: CurrencyCode) => void;
  setDefaultPaymentMethod: (method: 'COD' | 'Card' | 'JazzCash' | 'EasyPaisa' | 'BankTransfer' | 'WhatsApp') => void;

  // Cart & Fast COD Checkout
  addToCart: (product: Product, quantity?: number) => void;
  buyNowWithCOD: (product: Product, quantity?: number) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Product Management (Admin)
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, updated: Partial<Product>) => void;
  deleteProduct: (id: string) => void;

  // Order Management
  createOrder: (orderData: Omit<CustomerOrder, 'id' | 'orderNumber' | 'createdAt'>) => CustomerOrder;
  updateOrderStatus: (orderId: string, status: CustomerOrder['orderStatus'], courier?: string, tracking?: string) => void;
  
  // Customization (Admin)
  updateStoreConfig: (newConfig: Partial<StoreConfig>) => void;
  resetStoreConfig: () => void;

  // Currency Formatter
  formatPrice: (amountInPKR: number) => string;

  // Admin Auth
  adminLogin: (pinOrPass: string) => boolean;
  adminLogout: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('kb_products');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [orders, setOrders] = useState<CustomerOrder[]>(() => {
    try {
      const saved = localStorage.getItem('kb_orders');
      return saved ? JSON.parse(saved) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  const [storeConfig, setStoreConfig] = useState<StoreConfig>(() => {
    try {
      const saved = localStorage.getItem('kb_store_config');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_STORE_CONFIG,
          ...parsed,
          storeAddress: DEFAULT_STORE_CONFIG.storeAddress,
          whatsappNumber: DEFAULT_STORE_CONFIG.whatsappNumber,
          secondaryPhone: DEFAULT_STORE_CONFIG.secondaryPhone,
          supportEmail: DEFAULT_STORE_CONFIG.supportEmail,
        };
      }
      return DEFAULT_STORE_CONFIG;
    } catch {
      return DEFAULT_STORE_CONFIG;
    }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('kb_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('kb_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeCurrency, setActiveCurrency] = useState<CurrencyCode>('PKR');
  const [defaultPaymentMethod, setDefaultPaymentMethod] = useState<'COD' | 'Card' | 'JazzCash' | 'EasyPaisa' | 'BankTransfer' | 'WhatsApp'>('COD');

  const [isCartOpen, setCartOpen] = useState(false);
  const [isCheckoutOpen, setCheckoutOpen] = useState(false);
  const [isAdminDashboardOpen, setAdminDashboardOpen] = useState(false);
  const [isOrderTrackingOpen, setOrderTrackingOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('All Collection');
  const [selectedBrand, setSelectedBrand] = useState<string>('All Brands');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('kb_products', JSON.stringify(products));
    } catch (e) {
      console.error(e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('kb_orders', JSON.stringify(orders));
    } catch (e) {
      console.error(e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem('kb_cart', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('kb_wishlist', JSON.stringify(wishlist));
    } catch (e) {
      console.error(e);
    }
  }, [wishlist]);

  useEffect(() => {
    try {
      localStorage.setItem('kb_store_config', JSON.stringify(storeConfig));
      const root = document.documentElement;
      root.style.setProperty('--brand-primary', storeConfig.primaryColor);
      root.style.setProperty('--brand-accent', storeConfig.accentColor);
      root.style.setProperty('--brand-font-heading', `'${storeConfig.fontHeading}', serif`);
      root.style.setProperty('--brand-font-body', `'${storeConfig.fontBody}', sans-serif`);
      root.style.setProperty('--brand-body-bg', storeConfig.bodyBgColor || '#fafaf9');
      root.style.setProperty('--brand-text', storeConfig.textColor || '#18181b');
      root.style.setProperty('--brand-header-bg', storeConfig.headerBgColor || '#ffffff');
      root.style.setProperty('--brand-header-text', storeConfig.headerTextColor || '#0f172a');
      root.style.setProperty('--brand-footer-bg', storeConfig.footerBgColor || '#0a0a0a');
      root.style.setProperty('--brand-footer-text', storeConfig.footerTextColor || '#d4d4d8');
      
      const headingScale = storeConfig.headingFontSizeScale === 'xlarge' ? '1.3' : storeConfig.headingFontSizeScale === 'large' ? '1.15' : '1';
      root.style.setProperty('--heading-scale', headingScale);

      const bodyScale = storeConfig.bodyFontSizeScale === 'large' ? '1.1' : storeConfig.bodyFontSizeScale === 'compact' ? '0.92' : '1';
      root.style.setProperty('--body-scale', bodyScale);

      const headingWeight = storeConfig.headingFontWeight === 'bold' ? '700' : storeConfig.headingFontWeight === 'semibold' ? '600' : '400';
      root.style.setProperty('--heading-weight', headingWeight);
    } catch (e) {
      console.error(e);
    }
  }, [storeConfig]);

  const addToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    setCartOpen(true);
  };

  // Direct 1-click Fast Cash on Delivery (COD) Checkout
  const buyNowWithCOD = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    setDefaultPaymentMethod('COD');
    setSelectedProduct(null);
    setCartOpen(false);
    setCheckoutOpen(true);
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  const addProduct = (productData: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...productData,
      id: `kb-custom-${Date.now()}`
    };
    setProducts((prev) => [newProduct, ...prev]);
  };

  const updateProduct = (id: string, updated: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updated } : p))
    );
    if (selectedProduct && selectedProduct.id === id) {
      setSelectedProduct((prev) => (prev ? { ...prev, ...updated } : null));
    }
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    if (selectedProduct && selectedProduct.id === id) {
      setSelectedProduct(null);
    }
  };

  const createOrder = (orderData: Omit<CustomerOrder, 'id' | 'orderNumber' | 'createdAt'>) => {
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const newOrder: CustomerOrder = {
      ...orderData,
      id: `ord-${Date.now()}`,
      orderNumber: `KB-${randomSuffix}`,
      createdAt: new Date().toISOString(),
      orderStatus: 'Pending',
      courierName: 'TCS Express Pakistan',
      trackingNumber: `TCS-${Math.floor(100000000 + Math.random() * 900000000)}`
    };

    orderData.items.forEach((item) => {
      setProducts((prev) =>
        prev.map((p) =>
          p.id === item.productId
            ? { ...p, stock: Math.max(0, p.stock - item.quantity) }
            : p
        )
      );
    });

    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    return newOrder;
  };

  const updateOrderStatus = (
    orderId: string,
    status: CustomerOrder['orderStatus'],
    courier?: string,
    tracking?: string
  ) => {
    setOrders((prev) =>
      prev.map((ord) =>
        ord.id === orderId
          ? {
              ...ord,
              orderStatus: status,
              ...(courier ? { courierName: courier } : {}),
              ...(tracking ? { trackingNumber: tracking } : {}),
              ...(status === 'Delivered' ? { paymentStatus: 'Paid' } : {})
            }
          : ord
      )
    );
  };

  const updateStoreConfig = (newConfig: Partial<StoreConfig>) => {
    setStoreConfig((prev) => ({ ...prev, ...newConfig }));
  };

  const resetStoreConfig = () => {
    setStoreConfig(DEFAULT_STORE_CONFIG);
  };

  const formatPrice = (amountInPKR: number): string => {
    const rateObj = CURRENCY_RATES.find((r) => r.code === activeCurrency) || CURRENCY_RATES[0];
    const converted = amountInPKR * rateObj.rateAgainstPKR;
    
    if (rateObj.code === 'PKR') {
      return `Rs. ${amountInPKR.toLocaleString('en-PK')}`;
    }
    return `${rateObj.symbol}${converted.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`;
  };

  const adminLogin = (pinOrPass: string): boolean => {
    const trimmed = pinOrPass.trim();
    if (trimmed === 'admin' || trimmed === '7860' || trimmed === 'karachi2026') {
      setIsAdminLoggedIn(true);
      return true;
    }
    return false;
  };

  const adminLogout = () => {
    setIsAdminLoggedIn(false);
  };

  return (
    <StoreContext.Provider
      value={{
        products,
        orders,
        storeConfig,
        cart,
        wishlist,
        activeCurrency,
        isAdminLoggedIn,
        isCartOpen,
        isCheckoutOpen,
        isAdminDashboardOpen,
        isOrderTrackingOpen,
        selectedProduct,
        activeCategory,
        selectedBrand,
        searchQuery,
        defaultPaymentMethod,
        setCartOpen,
        setCheckoutOpen,
        setAdminDashboardOpen,
        setOrderTrackingOpen,
        setSelectedProduct,
        setActiveCategory,
        setSelectedBrand,
        setSearchQuery,
        setCurrency: setActiveCurrency,
        setDefaultPaymentMethod,
        addToCart,
        buyNowWithCOD,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        toggleWishlist,
        isInWishlist,
        addProduct,
        updateProduct,
        deleteProduct,
        createOrder,
        updateOrderStatus,
        updateStoreConfig,
        resetStoreConfig,
        formatPrice,
        adminLogin,
        adminLogout
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
