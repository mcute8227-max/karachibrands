import React from 'react';
import { useStore } from '../context/StoreContext';
import { ShieldCheck, Truck, Clock, Phone, MapPin, Mail, ArrowUp, Banknote } from 'lucide-react';

export const Footer: React.FC = () => {
  const { storeConfig, setActiveCategory } = useStore();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer 
      className="border-t border-neutral-800 text-xs font-sans transition-colors"
      style={{ 
        backgroundColor: storeConfig.footerBgColor || '#0a0a0a', 
        color: storeConfig.footerTextColor || '#d4d4d8' 
      }}
    >
      {/* Upper Brand Highlights */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 border-b border-neutral-800/80">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Col 1: Shop Story & Logo */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg overflow-hidden border border-neutral-700 bg-neutral-900 shadow-md shrink-0">
                <img
                  src={storeConfig.logoUrl || '/assets/aistudio/Gemini_Generated_Image_l5ybrzl5ybrzl5yb_6cf03367.jpg'}
                  alt="Karachi Brands Logo"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center"
                />
              </div>
              <div>
                <span className="font-heading text-lg font-bold text-white tracking-wide block">
                  {storeConfig.brandName}
                </span>
                <span className="text-[10px] text-amber-400 uppercase tracking-wider block">
                  {storeConfig.tagline || 'Original Unstitched'}
                </span>
              </div>
            </div>
            <p className="opacity-80 text-xs leading-relaxed">
              Your premier destination for 100% original Pakistani designer unstitched collections. Handpicked authentic articles from Saya, Khaadi, Sapphire, Nishat, Maria B, Asim Jofa and more.
            </p>
            {storeConfig.enableCOD && (
              <div className="text-[11px] text-amber-400 font-semibold flex items-center gap-1.5">
                <Banknote className="w-3.5 h-3.5 text-emerald-400" />
                <span>{storeConfig.codBadgeText || 'Cash on Delivery (COD) Available Across All Pakistan'}</span>
              </div>
            )}
          </div>

          {/* Col 2: Unstitched Collections */}
          {storeConfig.showFooterCollections && (
            <div className="space-y-2">
              <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-2">
                Collections
              </h4>
              <ul className="space-y-1.5 opacity-80">
                <li>
                  <button 
                    onClick={() => { setActiveCategory('New Arrivals'); window.scrollTo({ top: 400, behavior: 'smooth' }); }}
                    className="hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    New Arrivals '24-'25
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setActiveCategory('Summer Collection'); window.scrollTo({ top: 400, behavior: 'smooth' }); }}
                    className="hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    Summer Lawn & Chiffon
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setActiveCategory('Winter Collection'); window.scrollTo({ top: 400, behavior: 'smooth' }); }}
                    className="hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    Winter Khaddar & Shawls
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setActiveCategory('Fancy Articles'); window.scrollTo({ top: 400, behavior: 'smooth' }); }}
                    className="hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    Fancy & Wedding Formals
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setActiveCategory('Trending Articles'); window.scrollTo({ top: 400, behavior: 'smooth' }); }}
                    className="hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    Trending Articles
                  </button>
                </li>
              </ul>
            </div>
          )}

          {/* Col 3: Designer Brands */}
          {storeConfig.showFooterBrands && (
            <div className="space-y-2">
              <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-2">
                Original Brands
              </h4>
              <div className="grid grid-cols-2 gap-1.5 opacity-80">
                <span>Saya</span>
                <span>Khaadi</span>
                <span>Sapphire</span>
                <span>Nishat Linen</span>
                <span>Maria B</span>
                <span>Asim Jofa</span>
                <span>Sana Safinaz</span>
                <span>Gul Ahmed</span>
              </div>
              <p className="text-[11px] opacity-60 pt-2">
                100% Genuine Stamped Unstitched Fabrics with Manufacturer Inlays.
              </p>
            </div>
          )}

          {/* Col 4: Store Contact & Location */}
          {storeConfig.showFooterContact && (
            <div className="space-y-3">
              <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-2">
                Our Store Address & Support
              </h4>
              <div className="space-y-2 opacity-80 text-xs">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{storeConfig.storeAddress}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                  <span className="font-mono text-[11px]">{storeConfig.whatsappNumber} / {storeConfig.secondaryPhone || '+923014205395'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-amber-500 shrink-0" />
                  <a href={`mailto:${storeConfig.supportEmail}`} className="hover:underline">{storeConfig.supportEmail}</a>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>Mon - Sun: 10:00 AM - 11:00 PM (PST)</span>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Bottom Bar & Trust Strip */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] opacity-70">
        <div>
          {storeConfig.copyrightText || `© ${new Date().getFullYear()} ${storeConfig.brandName}. All Rights Reserved.`}
        </div>

        {/* Payment & Courier Partners */}
        {storeConfig.showFooterPaymentLogos && (
          <div className="flex items-center gap-3">
            {storeConfig.enableCOD && <span className="text-emerald-400 font-semibold">Cash on Delivery (COD)</span>}
            {storeConfig.enableCOD && <span>·</span>}
            <span>Visa & Mastercard</span>
            <span>·</span>
            <span>JazzCash / EasyPaisa</span>
            <span>·</span>
            <span>TCS Courier Express</span>
          </div>
        )}

        <button
          onClick={scrollToTop}
          className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
        >
          <span>Back to Top</span>
          <ArrowUp className="w-3.5 h-3.5" />
        </button>
      </div>
    </footer>
  );
};
