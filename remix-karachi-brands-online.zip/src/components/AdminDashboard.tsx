import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  X, 
  Lock, 
  Package, 
  ShoppingBag, 
  Palette, 
  BarChart3, 
  Plus, 
  Edit3, 
  Trash2, 
  Check, 
  LogOut,
  Save,
  Printer,
  Banknote,
  Layout,
  Sliders,
  Type,
  Layers,
  ShieldCheck,
  FileText,
  MoveUp,
  MoveDown,
  Sparkles,
  RefreshCw,
  Eye
} from 'lucide-react';
import { 
  Product, 
  CustomerOrder, 
  CategoryType, 
  BrandType, 
  FabricType, 
  PieceCount, 
  FontHeadingOption, 
  FontBodyOption,
  HeadingSizeScale,
  FontSizeScale
} from '../types';

export const AdminDashboard: React.FC = () => {
  const {
    isAdminDashboardOpen,
    setAdminDashboardOpen,
    isAdminLoggedIn,
    adminLogin,
    adminLogout,
    products,
    orders,
    storeConfig,
    formatPrice,
    addProduct,
    updateProduct,
    deleteProduct,
    updateOrderStatus,
    updateStoreConfig,
    resetStoreConfig
  } = useStore();

  const [activeTab, setActiveTab] = useState<'inventory' | 'orders' | 'customization' | 'analytics'>('inventory');
  const [customizerSubTab, setCustomizerSubTab] = useState<'header' | 'footer' | 'colors' | 'typography' | 'hero' | 'policies'>('header');
  const [pinInput, setPinInput] = useState('');
  const [loginError, setLoginError] = useState('');

  // Nav link addition state
  const [newNavInput, setNewNavInput] = useState('');

  // Inventory states
  const [inventorySearch, setInventorySearch] = useState('');
  const [isAddingNew, setIsAddingNew] = useState(false);

  // New product form
  const [newTitle, setNewTitle] = useState('');
  const [newBrand, setNewBrand] = useState<BrandType>('Saya');
  const [newCategory, setNewCategory] = useState<CategoryType>('Summer Collection');
  const [newFabric, setNewFabric] = useState<FabricType>('Lawn');
  const [newPieces, setNewPieces] = useState<PieceCount>('3-Piece');
  const [newPrice, setNewPrice] = useState<number>(7500);
  const [newOriginalPrice, setNewOriginalPrice] = useState<number>(8900);
  const [newStock, setNewStock] = useState<number>(10);
  const [newDupatta, setNewDupatta] = useState('Digital Chiffon Dupatta');
  const [newDescription, setNewDescription] = useState('');
  const [newImage, setNewImage] = useState('/src/assets/images/product_saya_embroidered_1793371043951.jpg');
  const [newCode, setNewCode] = useState('KB-ART-99');

  // Orders filter
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('All');
  const [selectedOrderDetails, setSelectedOrderDetails] = useState<CustomerOrder | null>(null);

  // Customization Form Local Copy
  const [tempConfig, setTempConfig] = useState(storeConfig);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    setTempConfig(storeConfig);
  }, [storeConfig, isAdminDashboardOpen]);

  if (!isAdminDashboardOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = adminLogin(pinInput);
    if (ok) {
      setLoginError('');
      setPinInput('');
    } else {
      setLoginError('Invalid PIN or Password. Use PIN 7860 or password "admin"');
    }
  };

  const handleAddNavLink = () => {
    if (!newNavInput.trim()) return;
    const trimmed = newNavInput.trim();
    if (!(tempConfig.navLinks || []).includes(trimmed)) {
      setTempConfig((prev) => ({
        ...prev,
        navLinks: [...(prev.navLinks || []), trimmed]
      }));
    }
    setNewNavInput('');
  };

  const handleRemoveNavLink = (indexToRemove: number) => {
    setTempConfig((prev) => ({
      ...prev,
      navLinks: (prev.navLinks || []).filter((_, idx) => idx !== indexToRemove)
    }));
  };

  const handleMoveNavLink = (index: number, direction: 'up' | 'down') => {
    const list = [...(tempConfig.navLinks || [])];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= list.length) return;
    const temp = list[index];
    list[index] = list[targetIdx];
    list[targetIdx] = temp;
    setTempConfig((prev) => ({
      ...prev,
      navLinks: list
    }));
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    addProduct({
      code: newCode || `KB-${Date.now().toString().slice(-4)}`,
      title: newTitle,
      brand: newBrand,
      category: newCategory,
      fabric: newFabric,
      pieces: newPieces,
      dupattaFabric: newDupatta,
      price: Number(newPrice),
      originalPrice: newOriginalPrice ? Number(newOriginalPrice) : undefined,
      stock: Number(newStock),
      rating: 5.0,
      reviewsCount: 1,
      isNewArrival: true,
      isTrending: false,
      isFancy: newCategory === 'Fancy Articles',
      description: newDescription || `Original ${newBrand} unstitched ${newPieces} ${newFabric} suit with ${newDupatta}.`,
      image: newImage,
      components: {
        shirt: '3.0 Meters Fabric',
        dupatta: `2.5 Meters ${newDupatta}`,
        trouser: '2.5 Meters Dyed Trouser Fabric',
        embroidery: 'Embroidered Neckline & Daman'
      }
    });

    setIsAddingNew(false);
    setNewTitle('');
    setNewPrice(7500);
  };

  const handleSaveCustomization = () => {
    updateStoreConfig(tempConfig);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const applyColorPreset = (preset: string) => {
    switch (preset) {
      case 'emerald-gold':
        setTempConfig((prev) => ({
          ...prev,
          themePreset: 'royal-emerald-gold',
          primaryColor: '#064e3b',
          accentColor: '#d97706',
          bodyBgColor: '#fafaf9',
          textColor: '#18181b',
          announcementBgColor: '#064e3b',
          announcementTextColor: '#fef08a',
          headerBgColor: '#ffffff',
          headerTextColor: '#064e3b',
          footerBgColor: '#022c22',
          footerTextColor: '#e2e8f0'
        }));
        break;
      case 'ruby-gold':
        setTempConfig((prev) => ({
          ...prev,
          themePreset: 'velvet-ruby-gold',
          primaryColor: '#881337',
          accentColor: '#d97706',
          bodyBgColor: '#fff1f2',
          textColor: '#1c1917',
          announcementBgColor: '#881337',
          announcementTextColor: '#fef08a',
          headerBgColor: '#ffffff',
          headerTextColor: '#881337',
          footerBgColor: '#4c0519',
          footerTextColor: '#fce7f3'
        }));
        break;
      case 'sapphire-amber':
        setTempConfig((prev) => ({
          ...prev,
          themePreset: 'sapphire-twilight',
          primaryColor: '#1e3a8a',
          accentColor: '#f59e0b',
          bodyBgColor: '#f8fafc',
          textColor: '#0f172a',
          announcementBgColor: '#172554',
          announcementTextColor: '#fde047',
          headerBgColor: '#ffffff',
          headerTextColor: '#1e3a8a',
          footerBgColor: '#0f172a',
          footerTextColor: '#e2e8f0'
        }));
        break;
      case 'midnight-rose':
        setTempConfig((prev) => ({
          ...prev,
          themePreset: 'midnight-rose',
          primaryColor: '#0f172a',
          accentColor: '#f43f5e',
          bodyBgColor: '#fdf4f5',
          textColor: '#18181b',
          announcementBgColor: '#0f172a',
          announcementTextColor: '#fda4af',
          headerBgColor: '#ffffff',
          headerTextColor: '#0f172a',
          footerBgColor: '#09090b',
          footerTextColor: '#e4e4e7'
        }));
        break;
      case 'classic-noir-gold':
        setTempConfig((prev) => ({
          ...prev,
          themePreset: 'classic-noir-gold',
          primaryColor: '#171717',
          accentColor: '#d97706',
          bodyBgColor: '#ffffff',
          textColor: '#171717',
          announcementBgColor: '#171717',
          announcementTextColor: '#fef3c7',
          headerBgColor: '#ffffff',
          headerTextColor: '#171717',
          footerBgColor: '#0a0a0a',
          footerTextColor: '#d4d4d8'
        }));
        break;
    }
  };

  const filteredInventory = products.filter((p) => {
    if (!inventorySearch.trim()) return true;
    const q = inventorySearch.toLowerCase();
    return (
      p.title.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.code.toLowerCase().includes(q)
    );
  });

  const filteredOrders = orders.filter((o) => {
    if (orderStatusFilter === 'All') return true;
    return o.orderStatus === orderStatusFilter;
  });

  const totalRevenue = orders.reduce((acc, o) => acc + o.total, 0);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div 
        className="relative bg-white rounded-xl shadow-2xl max-w-5xl w-full max-h-[94vh] flex flex-col overflow-hidden border border-neutral-300"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Admin Bar Header */}
        <div className="px-6 py-4 bg-neutral-900 text-white flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg overflow-hidden border border-neutral-700 bg-neutral-950 shrink-0">
              <img
                src={storeConfig.logoUrl || '/assets/aistudio/Gemini_Generated_Image_l5ybrzl5ybrzl5yb_6cf03367.jpg'}
                alt="Karachi Brands Logo"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h2 className="font-heading text-lg font-bold">
                {storeConfig.brandName} Management Studio
              </h2>
              <span className="text-[11px] text-neutral-400">
                Inventory, Orders, COD & Visual Customization Dashboard
              </span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {isAdminLoggedIn && (
              <button
                onClick={adminLogout}
                className="flex items-center gap-1 text-xs text-neutral-300 hover:text-white px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 cursor-pointer"
                title="Log Out"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            )}
            <button
              onClick={() => setAdminDashboardOpen(false)}
              className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PIN Screen */}
        {!isAdminLoggedIn ? (
          <div className="p-8 max-w-md mx-auto text-center my-auto">
            <div className="w-14 h-14 bg-amber-50 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-700 border border-amber-200">
              <Lock className="w-7 h-7" />
            </div>
            <h3 className="font-heading text-xl font-bold text-neutral-900 mb-1">
              Admin Access Authentication
            </h3>
            <p className="text-xs text-neutral-500 mb-6">
              Enter your master administrative PIN or password to manage stock inventory, customer orders, and store design.
            </p>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <input
                  type="password"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="Enter PIN (e.g. 7860 or admin)"
                  className="w-full px-4 py-2.5 text-center text-sm font-mono tracking-wider bg-neutral-50 border border-neutral-300 rounded-lg focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                  autoFocus
                />
              </div>

              {loginError && (
                <p className="text-xs text-red-600 font-medium">{loginError}</p>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold rounded-lg cursor-pointer transition-colors shadow-sm"
              >
                Unlock Dashboard
              </button>

              <div className="pt-2 text-[11px] text-neutral-400">
                Default Master PIN: <strong className="text-amber-800 font-mono">7860</strong> or password: <strong className="text-amber-800 font-mono">admin</strong>
              </div>
            </form>
          </div>
        ) : (
          /* Logged In Dashboard View */
          <div className="flex flex-col flex-1 overflow-hidden">
            
            {/* Tab Navigation */}
            <div className="px-6 bg-neutral-100/80 border-b border-neutral-200 flex gap-2 sm:gap-6 overflow-x-auto text-xs font-semibold text-neutral-600">
              <button
                onClick={() => setActiveTab('inventory')}
                className={`py-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap cursor-pointer transition-colors ${
                  activeTab === 'inventory'
                    ? 'border-neutral-900 text-neutral-900 font-bold'
                    : 'border-transparent hover:text-neutral-900'
                }`}
              >
                <Package className="w-4 h-4 text-amber-600" />
                <span>Inventory & Catalog ({products.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('orders')}
                className={`py-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap cursor-pointer transition-colors ${
                  activeTab === 'orders'
                    ? 'border-neutral-900 text-neutral-900 font-bold'
                    : 'border-transparent hover:text-neutral-900'
                }`}
              >
                <ShoppingBag className="w-4 h-4 text-amber-600" />
                <span>Customer Orders ({orders.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('customization')}
                className={`py-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap cursor-pointer transition-colors ${
                  activeTab === 'customization'
                    ? 'border-neutral-900 text-neutral-900 font-bold'
                    : 'border-transparent hover:text-neutral-900'
                }`}
              >
                <Palette className="w-4 h-4 text-amber-600" />
                <span>Customization Studio (Fonts & Colors)</span>
              </button>

              <button
                onClick={() => setActiveTab('analytics')}
                className={`py-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap cursor-pointer transition-colors ${
                  activeTab === 'analytics'
                    ? 'border-neutral-900 text-neutral-900 font-bold'
                    : 'border-transparent hover:text-neutral-900'
                }`}
              >
                <BarChart3 className="w-4 h-4 text-amber-600" />
                <span>Sales Overview</span>
              </button>
            </div>

            {/* TAB CONTENT CONTAINER */}
            <div className="flex-1 overflow-y-auto p-6 bg-neutral-50/50">
              
              {/* TAB 1: INVENTORY MANAGEMENT */}
              {activeTab === 'inventory' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-neutral-200">
                    <input
                      type="text"
                      value={inventorySearch}
                      onChange={(e) => setInventorySearch(e.target.value)}
                      placeholder="Search suits by brand or code..."
                      className="px-3 py-1.5 bg-neutral-50 border border-neutral-300 rounded-lg text-xs w-64 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />

                    <button
                      onClick={() => setIsAddingNew(true)}
                      className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Plus className="w-4 h-4 text-amber-400" />
                      <span>Add New Unstitched Article</span>
                    </button>
                  </div>

                  {isAddingNew && (
                    <div className="bg-white p-5 rounded-xl border-2 border-amber-500/40 shadow-md">
                      <div className="flex justify-between items-center mb-4">
                        <h4 className="font-heading text-sm font-bold text-neutral-900">
                          Add New Original Brand Unstitched Suit
                        </h4>
                        <button onClick={() => setIsAddingNew(false)} className="text-neutral-400 hover:text-neutral-700 cursor-pointer">
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      <form onSubmit={handleCreateProduct} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                        <div>
                          <label className="block font-semibold mb-1">Article Title *</label>
                          <input
                            type="text"
                            required
                            value={newTitle}
                            onChange={(e) => setNewTitle(e.target.value)}
                            placeholder="e.g. Blossom Embroidered Lawn 3PC"
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold mb-1">Brand *</label>
                          <select
                            value={newBrand}
                            onChange={(e) => setNewBrand(e.target.value as any)}
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                          >
                            <option value="Saya">Saya</option>
                            <option value="Khaadi">Khaadi</option>
                            <option value="Sapphire">Sapphire</option>
                            <option value="Nishat">Nishat</option>
                            <option value="Maria B">Maria B</option>
                            <option value="Asim Jofa">Asim Jofa</option>
                            <option value="Sana Safinaz">Sana Safinaz</option>
                            <option value="Gul Ahmed">Gul Ahmed</option>
                          </select>
                        </div>

                        <div>
                          <label className="block font-semibold mb-1">Category *</label>
                          <select
                            value={newCategory}
                            onChange={(e) => setNewCategory(e.target.value as any)}
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                          >
                            <option value="Summer Collection">Summer Collection</option>
                            <option value="Winter Collection">Winter Collection</option>
                            <option value="New Arrivals">New Arrivals</option>
                            <option value="Trending Articles">Trending Articles</option>
                            <option value="Fancy Articles">Fancy Articles</option>
                          </select>
                        </div>

                        <div>
                          <label className="block font-semibold mb-1">Fabric *</label>
                          <select
                            value={newFabric}
                            onChange={(e) => setNewFabric(e.target.value as any)}
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                          >
                            <option value="Lawn">Lawn</option>
                            <option value="Chiffon">Chiffon</option>
                            <option value="Khaddar">Khaddar</option>
                            <option value="Pure Silk">Pure Silk</option>
                            <option value="Organza">Organza</option>
                            <option value="Velvet">Velvet</option>
                            <option value="Cambric">Cambric</option>
                            <option value="Jacquard">Jacquard</option>
                          </select>
                        </div>

                        <div>
                          <label className="block font-semibold mb-1">Pieces</label>
                          <select
                            value={newPieces}
                            onChange={(e) => setNewPieces(e.target.value as any)}
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                          >
                            <option value="3-Piece">3-Piece</option>
                            <option value="2-Piece">2-Piece</option>
                            <option value="1-Piece">1-Piece</option>
                          </select>
                        </div>

                        <div>
                          <label className="block font-semibold mb-1">Price (PKR) *</label>
                          <input
                            type="number"
                            required
                            value={newPrice}
                            onChange={(e) => setNewPrice(Number(e.target.value))}
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold mb-1">Original Price (PKR)</label>
                          <input
                            type="number"
                            value={newOriginalPrice}
                            onChange={(e) => setNewOriginalPrice(Number(e.target.value))}
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold mb-1">Initial Stock Count *</label>
                          <input
                            type="number"
                            required
                            value={newStock}
                            onChange={(e) => setNewStock(Number(e.target.value))}
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block font-semibold mb-1">Dupatta Fabric & Specs</label>
                          <input
                            type="text"
                            value={newDupatta}
                            onChange={(e) => setNewDupatta(e.target.value)}
                            placeholder="e.g. Printed Pure Silk Dupatta 2.5m"
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block font-semibold mb-1">Select Preset Image</label>
                          <select
                            value={newImage}
                            onChange={(e) => setNewImage(e.target.value)}
                            className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                          >
                            <option value="/src/assets/images/product_saya_embroidered_1793371043951.jpg">Saya Pastel Mint Lawn (Catalog Photo 1)</option>
                            <option value="/src/assets/images/product_sapphire_summer_1793371044513.jpg">Sapphire Cobalt Indigo (Catalog Photo 2)</option>
                            <option value="/src/assets/images/product_mariab_fancy_1793371045879.jpg">Maria B Crimson Velvet Festive (Catalog Photo 3)</option>
                            <option value="/src/assets/images/product_khaadi_winter_1793371044615.jpg">Khaadi Emerald Pashmina Shawl (Catalog Photo 4)</option>
                          </select>
                        </div>

                        <div className="sm:col-span-4 flex justify-end gap-2 pt-2">
                          <button
                            type="button"
                            onClick={() => setIsAddingNew(false)}
                            className="px-4 py-2 border border-neutral-300 rounded text-neutral-700 hover:bg-neutral-100 cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="px-5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white font-semibold rounded cursor-pointer"
                          >
                            Save Article to Catalog
                          </button>
                        </div>
                      </form>
                    </div>
                  )}

                  <div className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-neutral-100 border-b border-neutral-200 font-bold text-neutral-700">
                          <tr>
                            <th className="p-3">Article</th>
                            <th className="p-3">Brand</th>
                            <th className="p-3">Category</th>
                            <th className="p-3">Fabric</th>
                            <th className="p-3">Price (PKR)</th>
                            <th className="p-3">Stock Qty</th>
                            <th className="p-3 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-neutral-100">
                          {filteredInventory.map((item) => (
                            <tr key={item.id} className="hover:bg-neutral-50/80">
                              <td className="p-3 flex items-center gap-3">
                                <img
                                  src={item.image}
                                  alt={item.title}
                                  referrerPolicy="no-referrer"
                                  className="w-10 h-10 object-cover rounded border border-neutral-200"
                                />
                                <div>
                                  <div className="font-semibold text-neutral-900 line-clamp-1">{item.title}</div>
                                  <div className="text-[10px] text-neutral-500 font-mono">{item.code} ({item.pieces})</div>
                                </div>
                              </td>
                              <td className="p-3 font-semibold text-neutral-800">{item.brand}</td>
                              <td className="p-3 text-neutral-600">{item.category}</td>
                              <td className="p-3 text-neutral-600">{item.fabric}</td>
                              <td className="p-3 font-mono font-bold text-neutral-900 tabular-nums">
                                Rs. {item.price.toLocaleString()}
                              </td>
                              <td className="p-3">
                                <span className={`inline-block font-mono font-bold px-2 py-0.5 rounded text-[11px] ${
                                  item.stock <= 3
                                    ? 'bg-red-100 text-red-700'
                                    : item.stock <= 8
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-emerald-100 text-emerald-800'
                                }`}>
                                  {item.stock} in stock
                                </span>
                              </td>
                              <td className="p-3 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => updateProduct(item.id, { stock: Math.max(0, item.stock - 1) })}
                                    className="px-1.5 py-0.5 border border-neutral-200 rounded text-neutral-600 hover:bg-neutral-100 cursor-pointer"
                                  >
                                    -
                                  </button>
                                  <button
                                    onClick={() => updateProduct(item.id, { stock: item.stock + 1 })}
                                    className="px-1.5 py-0.5 border border-neutral-200 rounded text-neutral-600 hover:bg-neutral-100 cursor-pointer"
                                  >
                                    +
                                  </button>
                                  <button
                                    onClick={() => {
                                      const newP = prompt('Enter new price in PKR:', item.price.toString());
                                      if (newP && !isNaN(Number(newP))) {
                                        updateProduct(item.id, { price: Number(newP) });
                                      }
                                    }}
                                    className="p-1.5 text-neutral-500 hover:text-amber-700 cursor-pointer"
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => {
                                      if (confirm(`Delete article ${item.title}?`)) {
                                        deleteProduct(item.id);
                                      }
                                    }}
                                    className="p-1.5 text-neutral-400 hover:text-red-600 cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: CUSTOMER ORDERS MANAGEMENT */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-xl border border-neutral-200">
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="font-semibold text-neutral-600 mr-1">Status Filter:</span>
                      {['All', 'Pending', 'Processing', 'Dispatched', 'Delivered', 'Cancelled'].map((st) => (
                        <button
                          key={st}
                          onClick={() => setOrderStatusFilter(st)}
                          className={`px-2.5 py-1 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                            orderStatusFilter === st
                              ? 'bg-neutral-900 text-white font-bold'
                              : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>

                    <div className="text-xs text-neutral-500 font-semibold">
                      Total Orders: {orders.length}
                    </div>
                  </div>

                  <div className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-neutral-100 border-b border-neutral-200 font-bold text-neutral-700">
                          <tr>
                            <th className="p-3">Order #</th>
                            <th className="p-3">Customer</th>
                            <th className="p-3">City</th>
                            <th className="p-3">Amount</th>
                            <th className="p-3">Payment</th>
                            <th className="p-3">Status</th>
                            <th className="p-3 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-neutral-100">
                          {filteredOrders.map((ord) => (
                            <tr key={ord.id} className="hover:bg-neutral-50/80">
                              <td className="p-3 font-mono font-bold text-neutral-900">
                                {ord.orderNumber}
                                <span className="block text-[10px] text-neutral-400 font-sans">
                                  {new Date(ord.createdAt).toLocaleDateString()}
                                </span>
                              </td>
                              <td className="p-3">
                                <div className="font-semibold text-neutral-800">{ord.customerName}</div>
                                <div className="text-[11px] text-neutral-500">{ord.phone}</div>
                              </td>
                              <td className="p-3 font-medium text-neutral-700">{ord.city}</td>
                              <td className="p-3 font-mono font-bold text-neutral-900 tabular-nums">
                                {formatPrice(ord.total)}
                              </td>
                              <td className="p-3">
                                <span className="text-[11px] font-semibold text-neutral-700 uppercase">
                                  {ord.paymentMethod === 'COD' ? 'Cash on Delivery (COD)' : ord.paymentMethod}
                                </span>
                                <span className={`block text-[10px] ${ord.paymentStatus === 'Paid' ? 'text-emerald-700 font-bold' : 'text-amber-700'}`}>
                                  ({ord.paymentStatus})
                                </span>
                              </td>
                              <td className="p-3">
                                <select
                                  value={ord.orderStatus}
                                  onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                                  className={`text-xs font-bold rounded px-2 py-1 border cursor-pointer ${
                                    ord.orderStatus === 'Delivered'
                                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                      : ord.orderStatus === 'Dispatched'
                                      ? 'bg-blue-50 text-blue-800 border-blue-300'
                                      : ord.orderStatus === 'Processing'
                                      ? 'bg-amber-50 text-amber-800 border-amber-300'
                                      : 'bg-neutral-100 text-neutral-800 border-neutral-300'
                                  }`}
                                >
                                  <option value="Pending">Pending</option>
                                  <option value="Processing">Processing</option>
                                  <option value="Dispatched">Dispatched</option>
                                  <option value="Delivered">Delivered</option>
                                  <option value="Cancelled">Cancelled</option>
                                </select>
                              </td>
                              <td className="p-3 text-right">
                                <button
                                  onClick={() => setSelectedOrderDetails(ord)}
                                  className="px-2.5 py-1 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded text-xs font-semibold cursor-pointer"
                                >
                                  Details
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {selectedOrderDetails && (
                    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4">
                      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 text-xs space-y-4">
                        <div className="flex justify-between items-center border-b pb-3">
                          <div>
                            <h4 className="font-heading text-sm font-bold text-neutral-900">
                              Order #{selectedOrderDetails.orderNumber} Details
                            </h4>
                            <span className="text-[11px] text-neutral-500">
                              Placed on {new Date(selectedOrderDetails.createdAt).toLocaleString()}
                            </span>
                          </div>
                          <button onClick={() => setSelectedOrderDetails(null)} className="cursor-pointer text-neutral-400 hover:text-neutral-700">
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        <div>
                          <h5 className="font-bold text-neutral-800 mb-1">Customer Shipping Info:</h5>
                          <p><strong>Name:</strong> {selectedOrderDetails.customerName}</p>
                          <p><strong>Phone / WhatsApp:</strong> {selectedOrderDetails.phone}</p>
                          <p><strong>Address:</strong> {selectedOrderDetails.address}, {selectedOrderDetails.city}</p>
                          <p><strong>Payment Choice:</strong> {selectedOrderDetails.paymentMethod === 'COD' ? 'Cash on Delivery (Pay at Door)' : selectedOrderDetails.paymentMethod}</p>
                          {selectedOrderDetails.notes && <p><strong>Notes:</strong> {selectedOrderDetails.notes}</p>}
                        </div>

                        <div className="border-t pt-3">
                          <h5 className="font-bold text-neutral-800 mb-2">Suits Ordered:</h5>
                          <div className="space-y-1.5 divide-y divide-neutral-100">
                            {selectedOrderDetails.items.map((it, idx) => (
                              <div key={idx} className="pt-1.5 flex justify-between">
                                <div>
                                  <span className="font-semibold text-neutral-900">{it.brand}</span>: {it.productTitle}
                                  <span className="text-neutral-500 block">Code: {it.productCode} × {it.quantity}</span>
                                </div>
                                <div className="font-bold font-mono">
                                  {formatPrice(it.price * it.quantity)}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="border-t pt-3 flex justify-between font-bold text-sm text-neutral-950">
                          <span>Total:</span>
                          <span className="text-amber-800 font-mono">{formatPrice(selectedOrderDetails.total)}</span>
                        </div>

                        <div className="flex justify-end gap-2 pt-2">
                          <button
                            onClick={() => window.print()}
                            className="px-3 py-1.5 border border-neutral-300 rounded text-neutral-700 font-medium hover:bg-neutral-50 flex items-center gap-1 cursor-pointer"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Print</span>
                          </button>
                          <button
                            onClick={() => setSelectedOrderDetails(null)}
                            className="px-4 py-1.5 bg-neutral-900 text-white rounded font-medium hover:bg-neutral-800 cursor-pointer"
                          >
                            Close
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              )}

              {/* TAB 3: THEME & VISUAL IDENTITY STUDIO */}
              {activeTab === 'customization' && (
                <div className="space-y-6">
                  {/* Studio Header Bar */}
                  <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
                        <h3 className="font-heading text-lg font-bold text-neutral-900">
                          Theme Upgrade & Customizer Studio
                        </h3>
                      </div>
                      <p className="text-xs text-neutral-500 mt-1">
                        Full control over website colors, fonts, header, footer, navigation links, hero banner, and COD policies.
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      {saveSuccess && (
                        <div className="px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 font-bold flex items-center gap-1.5 animate-bounce">
                          <Check className="w-4 h-4 text-emerald-600" />
                          <span>Final Changes Saved & Live!</span>
                        </div>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          resetStoreConfig();
                          setTempConfig(storeConfig);
                        }}
                        className="px-3 py-2 text-xs font-semibold text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg border border-neutral-300 transition-colors cursor-pointer"
                      >
                        Reset Defaults
                      </button>
                      <button
                        type="button"
                        onClick={handleSaveCustomization}
                        className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg flex items-center gap-2 cursor-pointer shadow-md transition-all transform hover:-translate-y-0.5"
                      >
                        <Save className="w-4 h-4" />
                        <span>Save & Publish Final Changes</span>
                      </button>
                    </div>
                  </div>

                  {/* Customizer Sub-Navigation Tabs */}
                  <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-neutral-200/70 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setCustomizerSubTab('header')}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        customizerSubTab === 'header'
                          ? 'bg-white text-neutral-900 shadow-xs'
                          : 'text-neutral-600 hover:text-neutral-900 hover:bg-white/50'
                      }`}
                    >
                      <Layout className="w-3.5 h-3.5 text-amber-600" />
                      <span>Header & Navigation</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setCustomizerSubTab('colors')}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        customizerSubTab === 'colors'
                          ? 'bg-white text-neutral-900 shadow-xs'
                          : 'text-neutral-600 hover:text-neutral-900 hover:bg-white/50'
                      }`}
                    >
                      <Palette className="w-3.5 h-3.5 text-amber-600" />
                      <span>Color Scheme & Palette</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setCustomizerSubTab('typography')}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        customizerSubTab === 'typography'
                          ? 'bg-white text-neutral-900 shadow-xs'
                          : 'text-neutral-600 hover:text-neutral-900 hover:bg-white/50'
                      }`}
                    >
                      <Type className="w-3.5 h-3.5 text-amber-600" />
                      <span>Typography & Font Sizes</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setCustomizerSubTab('hero')}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        customizerSubTab === 'hero'
                          ? 'bg-white text-neutral-900 shadow-xs'
                          : 'text-neutral-600 hover:text-neutral-900 hover:bg-white/50'
                      }`}
                    >
                      <Layers className="w-3.5 h-3.5 text-amber-600" />
                      <span>Hero Banner & Pillars</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setCustomizerSubTab('footer')}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        customizerSubTab === 'footer'
                          ? 'bg-white text-neutral-900 shadow-xs'
                          : 'text-neutral-600 hover:text-neutral-900 hover:bg-white/50'
                      }`}
                    >
                      <FileText className="w-3.5 h-3.5 text-amber-600" />
                      <span>Footer & Store Info</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setCustomizerSubTab('policies')}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        customizerSubTab === 'policies'
                          ? 'bg-white text-neutral-900 shadow-xs'
                          : 'text-neutral-600 hover:text-neutral-900 hover:bg-white/50'
                      }`}
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                      <span>COD & Policies</span>
                    </button>
                  </div>

                  {/* SUBSECTION 1: HEADER & NAVIGATION */}
                  {customizerSubTab === 'header' && (
                    <div className="bg-white p-6 rounded-xl border border-neutral-200 space-y-6">
                      <div className="border-b pb-4">
                        <h4 className="font-heading text-sm font-bold text-neutral-900">
                          Header Styling, Top Announcement & Navigation Menu
                        </h4>
                        <p className="text-xs text-neutral-500">
                          Customize header colors, top announcement text, logo size, and add or remove navigation categories.
                        </p>
                      </div>

                      {/* Header Colors */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                            Header Background Color
                          </label>
                          <div className="flex items-center gap-3">
                            <input
                              type="color"
                              value={tempConfig.headerBgColor || '#ffffff'}
                              onChange={(e) => setTempConfig({ ...tempConfig, headerBgColor: e.target.value })}
                              className="w-10 h-10 rounded border border-neutral-300 p-0.5 cursor-pointer"
                            />
                            <input
                              type="text"
                              value={tempConfig.headerBgColor || '#ffffff'}
                              onChange={(e) => setTempConfig({ ...tempConfig, headerBgColor: e.target.value })}
                              className="flex-1 px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                            Header Text & Link Color
                          </label>
                          <div className="flex items-center gap-3">
                            <input
                              type="color"
                              value={tempConfig.headerTextColor || '#0f172a'}
                              onChange={(e) => setTempConfig({ ...tempConfig, headerTextColor: e.target.value })}
                              className="w-10 h-10 rounded border border-neutral-300 p-0.5 cursor-pointer"
                            />
                            <input
                              type="text"
                              value={tempConfig.headerTextColor || '#0f172a'}
                              onChange={(e) => setTempConfig({ ...tempConfig, headerTextColor: e.target.value })}
                              className="flex-1 px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Announcement Bar Settings */}
                      <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-bold text-neutral-900 flex items-center gap-2">
                            <span>Top Announcement Ticker Bar</span>
                          </label>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={tempConfig.showAnnouncement}
                              onChange={(e) => setTempConfig({ ...tempConfig, showAnnouncement: e.target.checked })}
                              className="sr-only peer"
                            />
                            <div className="w-9 h-5 bg-neutral-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                            <span className="ml-2 text-xs font-semibold text-neutral-700">
                              {tempConfig.showAnnouncement ? 'Visible' : 'Hidden'}
                            </span>
                          </label>
                        </div>

                        {tempConfig.showAnnouncement && (
                          <div className="space-y-3 pt-2">
                            <div>
                              <label className="block text-[11px] font-semibold text-neutral-600 mb-1">
                                Announcement Ticker Text
                              </label>
                              <input
                                type="text"
                                value={tempConfig.announcementText}
                                onChange={(e) => setTempConfig({ ...tempConfig, announcementText: e.target.value })}
                                className="w-full px-3 py-2 border border-neutral-300 rounded text-xs"
                              />
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              <div>
                                <label className="block text-[11px] font-semibold text-neutral-600 mb-1">
                                  Announcement Bar Background
                                </label>
                                <div className="flex items-center gap-2">
                                  <input
                                    type="color"
                                    value={tempConfig.announcementBgColor || '#0f172a'}
                                    onChange={(e) => setTempConfig({ ...tempConfig, announcementBgColor: e.target.value })}
                                    className="w-8 h-8 rounded border border-neutral-300 p-0.5 cursor-pointer"
                                  />
                                  <input
                                    type="text"
                                    value={tempConfig.announcementBgColor || '#0f172a'}
                                    onChange={(e) => setTempConfig({ ...tempConfig, announcementBgColor: e.target.value })}
                                    className="flex-1 px-2.5 py-1.5 border border-neutral-300 rounded font-mono text-xs"
                                  />
                                </div>
                              </div>

                              <div>
                                <label className="block text-[11px] font-semibold text-neutral-600 mb-1">
                                  Announcement Text Color
                                </label>
                                <div className="flex items-center gap-2">
                                  <input
                                    type="color"
                                    value={tempConfig.announcementTextColor || '#fde047'}
                                    onChange={(e) => setTempConfig({ ...tempConfig, announcementTextColor: e.target.value })}
                                    className="w-8 h-8 rounded border border-neutral-300 p-0.5 cursor-pointer"
                                  />
                                  <input
                                    type="text"
                                    value={tempConfig.announcementTextColor || '#fde047'}
                                    onChange={(e) => setTempConfig({ ...tempConfig, announcementTextColor: e.target.value })}
                                    className="flex-1 px-2.5 py-1.5 border border-neutral-300 rounded font-mono text-xs"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Logo Size Selection */}
                      <div>
                        <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-2">
                          Store Logo Size
                        </label>
                        <div className="grid grid-cols-3 gap-3">
                          {[
                            { id: 'small', label: 'Small', desc: 'Compact (36px high)' },
                            { id: 'medium', label: 'Medium', desc: 'Standard (48px high)' },
                            { id: 'large', label: 'Large', desc: 'Prominent (56px high)' },
                          ].map((s) => (
                            <button
                              key={s.id}
                              type="button"
                              onClick={() => setTempConfig({ ...tempConfig, logoSize: s.id as any })}
                              className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                                tempConfig.logoSize === s.id
                                  ? 'border-amber-600 bg-amber-50/50 ring-1 ring-amber-600'
                                  : 'border-neutral-200 hover:bg-neutral-50'
                              }`}
                            >
                              <div className="text-xs font-bold text-neutral-900">{s.label}</div>
                              <div className="text-[10px] text-neutral-500">{s.desc}</div>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Navigation Menu Links Manager */}
                      <div className="pt-4 border-t border-neutral-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h5 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                              Header Navigation Menu Links
                            </h5>
                            <p className="text-[11px] text-neutral-500">
                              Add, reorder, or remove navigation links displayed across the store header.
                            </p>
                          </div>
                          <span className="text-xs font-bold text-neutral-600 bg-neutral-100 px-2.5 py-1 rounded">
                            {(tempConfig.navLinks || []).length} Active Links
                          </span>
                        </div>

                        {/* Current Links List */}
                        <div className="space-y-2">
                          {(tempConfig.navLinks || []).map((link, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between p-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs"
                            >
                              <div className="flex items-center gap-2.5">
                                <span className="w-5 h-5 rounded-full bg-neutral-200 text-neutral-700 flex items-center justify-center font-bold text-[10px]">
                                  {idx + 1}
                                </span>
                                <span className="font-semibold text-neutral-800">{link}</span>
                              </div>

                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => handleMoveNavLink(idx, 'up')}
                                  disabled={idx === 0}
                                  title="Move Up"
                                  className="p-1 hover:bg-neutral-200 rounded text-neutral-600 disabled:opacity-30 cursor-pointer"
                                >
                                  <MoveUp className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleMoveNavLink(idx, 'down')}
                                  disabled={idx === (tempConfig.navLinks || []).length - 1}
                                  title="Move Down"
                                  className="p-1 hover:bg-neutral-200 rounded text-neutral-600 disabled:opacity-30 cursor-pointer"
                                >
                                  <MoveDown className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleRemoveNavLink(idx)}
                                  title="Remove Link"
                                  className="p-1 hover:bg-rose-100 rounded text-rose-600 transition-colors cursor-pointer ml-1"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Add New Navigation Link */}
                        <div className="p-3 bg-amber-50/50 rounded-lg border border-amber-200 flex flex-col sm:flex-row items-center gap-2">
                          <input
                            type="text"
                            placeholder="e.g. Festive Silks or Eid Specials"
                            value={newNavInput}
                            onChange={(e) => setNewNavInput(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handleAddNavLink();
                              }
                            }}
                            className="flex-1 px-3 py-2 bg-white border border-amber-300 rounded text-xs font-medium focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={handleAddNavLink}
                            className="w-full sm:w-auto px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add Menu Link</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* SUBSECTION 2: COLOR SCHEME & PALETTE */}
                  {customizerSubTab === 'colors' && (
                    <div className="bg-white p-6 rounded-xl border border-neutral-200 space-y-6">
                      <div className="border-b pb-4">
                        <h4 className="font-heading text-sm font-bold text-neutral-900">
                          Luxury Color Palette & Theme Scheme
                        </h4>
                        <p className="text-xs text-neutral-500">
                          Select from one of 5 authentic Pakistani luxury boutique presets, or customize exact hex shades.
                        </p>
                      </div>

                      {/* 5 Luxury Presets */}
                      <div className="space-y-3">
                        <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider">
                          1-Click Luxury Theme Presets
                        </label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                          <button
                            type="button"
                            onClick={() => applyColorPreset('emerald-gold')}
                            className={`p-3.5 rounded-lg border text-left cursor-pointer transition-all ${
                              tempConfig.themePreset === 'royal-emerald-gold'
                                ? 'border-amber-600 bg-amber-50/50 ring-2 ring-amber-600/40'
                                : 'border-neutral-200 hover:bg-neutral-50'
                            }`}
                          >
                            <div className="flex gap-2 mb-2">
                              <span className="w-6 h-6 rounded-full bg-[#064e3b] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#d97706] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#fafaf9] border border-neutral-200 shadow-xs" />
                            </div>
                            <div className="text-xs font-bold text-neutral-900">Royal Emerald & Gold</div>
                            <div className="text-[10px] text-neutral-500">Classic Pakistani Couture</div>
                          </button>

                          <button
                            type="button"
                            onClick={() => applyColorPreset('ruby-gold')}
                            className={`p-3.5 rounded-lg border text-left cursor-pointer transition-all ${
                              tempConfig.themePreset === 'velvet-ruby-gold'
                                ? 'border-amber-600 bg-amber-50/50 ring-2 ring-amber-600/40'
                                : 'border-neutral-200 hover:bg-neutral-50'
                            }`}
                          >
                            <div className="flex gap-2 mb-2">
                              <span className="w-6 h-6 rounded-full bg-[#881337] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#d97706] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#fff1f2] border border-neutral-200 shadow-xs" />
                            </div>
                            <div className="text-xs font-bold text-neutral-900">Velvet Ruby & Gold</div>
                            <div className="text-[10px] text-neutral-500">Bridal & Festive Elegance</div>
                          </button>

                          <button
                            type="button"
                            onClick={() => applyColorPreset('sapphire-amber')}
                            className={`p-3.5 rounded-lg border text-left cursor-pointer transition-all ${
                              tempConfig.themePreset === 'sapphire-twilight'
                                ? 'border-amber-600 bg-amber-50/50 ring-2 ring-amber-600/40'
                                : 'border-neutral-200 hover:bg-neutral-50'
                            }`}
                          >
                            <div className="flex gap-2 mb-2">
                              <span className="w-6 h-6 rounded-full bg-[#1e3a8a] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#f59e0b] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#f8fafc] border border-neutral-200 shadow-xs" />
                            </div>
                            <div className="text-xs font-bold text-neutral-900">Sapphire Twilight</div>
                            <div className="text-[10px] text-neutral-500">Royal Modern Aesthetic</div>
                          </button>

                          <button
                            type="button"
                            onClick={() => applyColorPreset('midnight-rose')}
                            className={`p-3.5 rounded-lg border text-left cursor-pointer transition-all ${
                              tempConfig.themePreset === 'midnight-rose'
                                ? 'border-amber-600 bg-amber-50/50 ring-2 ring-amber-600/40'
                                : 'border-neutral-200 hover:bg-neutral-50'
                            }`}
                          >
                            <div className="flex gap-2 mb-2">
                              <span className="w-6 h-6 rounded-full bg-[#0f172a] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#f43f5e] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#fdf4f5] border border-neutral-200 shadow-xs" />
                            </div>
                            <div className="text-xs font-bold text-neutral-900">Midnight Onyx & Rose</div>
                            <div className="text-[10px] text-neutral-500">High-Fashion Contemporary</div>
                          </button>

                          <button
                            type="button"
                            onClick={() => applyColorPreset('classic-noir-gold')}
                            className={`p-3.5 rounded-lg border text-left cursor-pointer transition-all ${
                              tempConfig.themePreset === 'classic-noir-gold'
                                ? 'border-amber-600 bg-amber-50/50 ring-2 ring-amber-600/40'
                                : 'border-neutral-200 hover:bg-neutral-50'
                            }`}
                          >
                            <div className="flex gap-2 mb-2">
                              <span className="w-6 h-6 rounded-full bg-[#171717] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#d97706] shadow-xs" />
                              <span className="w-6 h-6 rounded-full bg-[#ffffff] border border-neutral-200 shadow-xs" />
                            </div>
                            <div className="text-xs font-bold text-neutral-900">Classic Noir & Gold</div>
                            <div className="text-[10px] text-neutral-500">Glossy Editorial Black & Gold</div>
                          </button>
                        </div>
                      </div>

                      {/* Granular Color Pickers */}
                      <div className="pt-4 border-t border-neutral-200 space-y-4">
                        <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider">
                          Granular Color Customization
                        </label>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Primary Brand Color (Buttons & Badges)
                            </label>
                            <div className="flex items-center gap-2">
                              <input
                                type="color"
                                value={tempConfig.primaryColor || '#0f172a'}
                                onChange={(e) => setTempConfig({ ...tempConfig, primaryColor: e.target.value })}
                                className="w-10 h-10 rounded border border-neutral-300 p-0.5 cursor-pointer"
                              />
                              <input
                                type="text"
                                value={tempConfig.primaryColor || '#0f172a'}
                                onChange={(e) => setTempConfig({ ...tempConfig, primaryColor: e.target.value })}
                                className="flex-1 px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Accent Gold Color (Stars, Highlights & Prices)
                            </label>
                            <div className="flex items-center gap-2">
                              <input
                                type="color"
                                value={tempConfig.accentColor || '#d97706'}
                                onChange={(e) => setTempConfig({ ...tempConfig, accentColor: e.target.value })}
                                className="w-10 h-10 rounded border border-neutral-300 p-0.5 cursor-pointer"
                              />
                              <input
                                type="text"
                                value={tempConfig.accentColor || '#d97706'}
                                onChange={(e) => setTempConfig({ ...tempConfig, accentColor: e.target.value })}
                                className="flex-1 px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Website Body Background Tone
                            </label>
                            <div className="flex items-center gap-2">
                              <input
                                type="color"
                                value={tempConfig.bodyBgColor || '#fafaf9'}
                                onChange={(e) => setTempConfig({ ...tempConfig, bodyBgColor: e.target.value })}
                                className="w-10 h-10 rounded border border-neutral-300 p-0.5 cursor-pointer"
                              />
                              <input
                                type="text"
                                value={tempConfig.bodyBgColor || '#fafaf9'}
                                onChange={(e) => setTempConfig({ ...tempConfig, bodyBgColor: e.target.value })}
                                className="flex-1 px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Website Main Text Color
                            </label>
                            <div className="flex items-center gap-2">
                              <input
                                type="color"
                                value={tempConfig.textColor || '#18181b'}
                                onChange={(e) => setTempConfig({ ...tempConfig, textColor: e.target.value })}
                                className="w-10 h-10 rounded border border-neutral-300 p-0.5 cursor-pointer"
                              />
                              <input
                                type="text"
                                value={tempConfig.textColor || '#18181b'}
                                onChange={(e) => setTempConfig({ ...tempConfig, textColor: e.target.value })}
                                className="flex-1 px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* SUBSECTION 3: TYPOGRAPHY & FONT SIZES */}
                  {customizerSubTab === 'typography' && (
                    <div className="bg-white p-6 rounded-xl border border-neutral-200 space-y-6">
                      <div className="border-b pb-4">
                        <h4 className="font-heading text-sm font-bold text-neutral-900">
                          Typography, Font Families & Scale Controls
                        </h4>
                        <p className="text-xs text-neutral-500">
                          Choose luxury display serif fonts for headlines, modern sans fonts for body copy, and adjust scale multipliers.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1.5">
                            Headline Display Font Family
                          </label>
                          <select
                            value={tempConfig.fontHeading}
                            onChange={(e) => setTempConfig({ ...tempConfig, fontHeading: e.target.value as FontHeadingOption })}
                            className="w-full px-3 py-2.5 border border-neutral-300 rounded-lg text-xs font-semibold focus:outline-none"
                          >
                            <option value="Playfair Display">Playfair Display (Vogue Luxury Serif)</option>
                            <option value="Cinzel">Cinzel (Imperial Roman Royal)</option>
                            <option value="Cormorant Garamond">Cormorant Garamond (Graceful Vintage)</option>
                            <option value="Montserrat">Montserrat (Modern Architectural)</option>
                            <option value="Outfit">Outfit (Clean Geometric Luxury)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1.5">
                            Body Prose Font Family
                          </label>
                          <select
                            value={tempConfig.fontBody}
                            onChange={(e) => setTempConfig({ ...tempConfig, fontBody: e.target.value as FontBodyOption })}
                            className="w-full px-3 py-2.5 border border-neutral-300 rounded-lg text-xs font-semibold focus:outline-none"
                          >
                            <option value="Plus Jakarta Sans">Plus Jakarta Sans (Ultra-clean, crisp reading)</option>
                            <option value="Montserrat">Montserrat (Fashion standard typography)</option>
                            <option value="Outfit">Outfit (Contemporary soft geometric)</option>
                          </select>
                        </div>
                      </div>

                      {/* Font Size Scales & Weight */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                        <div>
                          <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1.5">
                            Headline Size Scale
                          </label>
                          <select
                            value={tempConfig.headingFontSizeScale || 'normal'}
                            onChange={(e) => setTempConfig({ ...tempConfig, headingFontSizeScale: e.target.value as HeadingSizeScale })}
                            className="w-full px-3 py-2.5 border border-neutral-300 rounded-lg text-xs font-semibold focus:outline-none"
                          >
                            <option value="normal">Normal (100% standard size)</option>
                            <option value="large">Large (+15% bold impact)</option>
                            <option value="xlarge">Extra Large (+30% dramatic luxury)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1.5">
                            Body Font Size Scale
                          </label>
                          <select
                            value={tempConfig.bodyFontSizeScale || 'standard'}
                            onChange={(e) => setTempConfig({ ...tempConfig, bodyFontSizeScale: e.target.value as FontSizeScale })}
                            className="w-full px-3 py-2.5 border border-neutral-300 rounded-lg text-xs font-semibold focus:outline-none"
                          >
                            <option value="compact">Compact (14px - dense catalog)</option>
                            <option value="standard">Standard (15px - optimal)</option>
                            <option value="large">Comfortable (16px - easy reading)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1.5">
                            Headline Font Weight
                          </label>
                          <select
                            value={tempConfig.headingFontWeight || 'bold'}
                            onChange={(e) => setTempConfig({ ...tempConfig, headingFontWeight: e.target.value as any })}
                            className="w-full px-3 py-2.5 border border-neutral-300 rounded-lg text-xs font-semibold focus:outline-none"
                          >
                            <option value="normal">Regular (400)</option>
                            <option value="semibold">Semi-Bold (600)</option>
                            <option value="bold">Bold (700)</option>
                          </select>
                        </div>
                      </div>

                      {/* Live Typography Preview Box */}
                      <div className="p-5 bg-neutral-50 rounded-xl border border-neutral-200">
                        <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block mb-2">
                          Live Typography Preview
                        </span>
                        <h2 
                          style={{ fontFamily: tempConfig.fontHeading }}
                          className={`text-2xl sm:text-3xl text-neutral-900 mb-2 ${
                            tempConfig.headingFontWeight === 'bold' ? 'font-bold' : tempConfig.headingFontWeight === 'semibold' ? 'font-semibold' : 'font-normal'
                          }`}
                        >
                          {tempConfig.brandName} - Luxury Unstitched Lawn
                        </h2>
                        <p 
                          style={{ fontFamily: tempConfig.fontBody }}
                          className="text-sm text-neutral-600 leading-relaxed max-w-xl"
                        >
                          Experience royal Pakistani couture crafted from 100% original brand lawns, jacquards, and silks. Fast home delivery in Sheikhupura and nationwide cash on delivery.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* SUBSECTION 4: HERO BANNER & PILLARS */}
                  {customizerSubTab === 'hero' && (
                    <div className="bg-white p-6 rounded-xl border border-neutral-200 space-y-6">
                      <div className="border-b pb-4">
                        <h4 className="font-heading text-sm font-bold text-neutral-900">
                          Hero Showcase Banner & 4 Trust Pillars
                        </h4>
                        <p className="text-xs text-neutral-500">
                          Change hero headline text, call-to-action button labels, background image, and customize the 4 value proposition strips.
                        </p>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                            Hero Banner Headline
                          </label>
                          <input
                            type="text"
                            value={tempConfig.bannerHeadline}
                            onChange={(e) => setTempConfig({ ...tempConfig, bannerHeadline: e.target.value })}
                            className="w-full px-3 py-2 border border-neutral-300 rounded text-xs font-semibold"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                            Hero Banner Subheadline
                          </label>
                          <textarea
                            rows={3}
                            value={tempConfig.bannerSubheadline}
                            onChange={(e) => setTempConfig({ ...tempConfig, bannerSubheadline: e.target.value })}
                            className="w-full px-3 py-2 border border-neutral-300 rounded text-xs leading-relaxed"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Primary Button Text
                            </label>
                            <input
                              type="text"
                              value={tempConfig.bannerPrimaryBtnText || 'Explore Summer Lawn'}
                              onChange={(e) => setTempConfig({ ...tempConfig, bannerPrimaryBtnText: e.target.value })}
                              className="w-full px-3 py-2 border border-neutral-300 rounded text-xs"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Secondary Button Text
                            </label>
                            <input
                              type="text"
                              value={tempConfig.bannerSecondaryBtnText || 'Festive & Fancy Suits'}
                              onChange={(e) => setTempConfig({ ...tempConfig, bannerSecondaryBtnText: e.target.value })}
                              className="w-full px-3 py-2 border border-neutral-300 rounded text-xs"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Hero Image URL
                          </label>
                          <input
                            type="text"
                            value={tempConfig.bannerImageUrl || ''}
                            onChange={(e) => setTempConfig({ ...tempConfig, bannerImageUrl: e.target.value })}
                            placeholder="/src/assets/images/hero_luxury_lawn_1793371043902.jpg"
                            className="w-full px-3 py-2 border border-neutral-300 rounded font-mono text-xs"
                          />
                        </div>
                      </div>

                      {/* Trust Pillars Strip Settings */}
                      <div className="pt-4 border-t border-neutral-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h5 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                              Trust Value Pillars (4-Feature Banner)
                            </h5>
                            <p className="text-[11px] text-neutral-500">
                              Customizable guarantee badges shown directly under the hero banner.
                            </p>
                          </div>

                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={tempConfig.showTrustPillars !== false}
                              onChange={(e) => setTempConfig({ ...tempConfig, showTrustPillars: e.target.checked })}
                              className="sr-only peer"
                            />
                            <div className="w-9 h-5 bg-neutral-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                            <span className="ml-2 text-xs font-semibold text-neutral-700">
                              {tempConfig.showTrustPillars !== false ? 'Shown' : 'Hidden'}
                            </span>
                          </label>
                        </div>

                        {tempConfig.showTrustPillars !== false && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                            <div>
                              <label className="block text-[11px] font-semibold text-neutral-600 mb-1">
                                Pillar 1: Original Brand Guarantee
                              </label>
                              <input
                                type="text"
                                value={tempConfig.pillar1Text || 'Saya, Khaadi, Sapphire & more'}
                                onChange={(e) => setTempConfig({ ...tempConfig, pillar1Text: e.target.value })}
                                className="w-full px-3 py-1.5 border border-neutral-300 rounded text-xs"
                              />
                            </div>

                            <div>
                              <label className="block text-[11px] font-semibold text-neutral-600 mb-1">
                                Pillar 2: Cash on Delivery (COD)
                              </label>
                              <input
                                type="text"
                                value={tempConfig.pillar2Text || 'Pay courier upon parcel arrival'}
                                onChange={(e) => setTempConfig({ ...tempConfig, pillar2Text: e.target.value })}
                                className="w-full px-3 py-1.5 border border-neutral-300 rounded text-xs"
                              />
                            </div>

                            <div>
                              <label className="block text-[11px] font-semibold text-neutral-600 mb-1">
                                Pillar 3: Fast Home Delivery
                              </label>
                              <input
                                type="text"
                                value={tempConfig.pillar3Text || 'Sheikhupura & Nationwide'}
                                onChange={(e) => setTempConfig({ ...tempConfig, pillar3Text: e.target.value })}
                                className="w-full px-3 py-1.5 border border-neutral-300 rounded text-xs"
                              />
                            </div>

                            <div>
                              <label className="block text-[11px] font-semibold text-neutral-600 mb-1">
                                Pillar 4: Easy Replacement Policy
                              </label>
                              <input
                                type="text"
                                value={tempConfig.pillar4Text || 'Hassle-free replacement policy'}
                                onChange={(e) => setTempConfig({ ...tempConfig, pillar4Text: e.target.value })}
                                className="w-full px-3 py-1.5 border border-neutral-300 rounded text-xs"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* SUBSECTION 5: FOOTER & STORE INFO */}
                  {customizerSubTab === 'footer' && (
                    <div className="bg-white p-6 rounded-xl border border-neutral-200 space-y-6">
                      <div className="border-b pb-4">
                        <h4 className="font-heading text-sm font-bold text-neutral-900">
                          Footer Styling, Copyright & Store Contact Information
                        </h4>
                        <p className="text-xs text-neutral-500">
                          Configure footer background colors, toggle footer sections, and update official Sheikhupura address and WhatsApp lines.
                        </p>
                      </div>

                      {/* Footer Colors */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                            Footer Background Color
                          </label>
                          <div className="flex items-center gap-3">
                            <input
                              type="color"
                              value={tempConfig.footerBgColor || '#0a0a0a'}
                              onChange={(e) => setTempConfig({ ...tempConfig, footerBgColor: e.target.value })}
                              className="w-10 h-10 rounded border border-neutral-300 p-0.5 cursor-pointer"
                            />
                            <input
                              type="text"
                              value={tempConfig.footerBgColor || '#0a0a0a'}
                              onChange={(e) => setTempConfig({ ...tempConfig, footerBgColor: e.target.value })}
                              className="flex-1 px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                            Footer Text Color
                          </label>
                          <div className="flex items-center gap-3">
                            <input
                              type="color"
                              value={tempConfig.footerTextColor || '#d4d4d8'}
                              onChange={(e) => setTempConfig({ ...tempConfig, footerTextColor: e.target.value })}
                              className="w-10 h-10 rounded border border-neutral-300 p-0.5 cursor-pointer"
                            />
                            <input
                              type="text"
                              value={tempConfig.footerTextColor || '#d4d4d8'}
                              onChange={(e) => setTempConfig({ ...tempConfig, footerTextColor: e.target.value })}
                              className="flex-1 px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Section Visibility Toggles */}
                      <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200 space-y-3">
                        <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider">
                          Footer Columns & Badges Visibility
                        </label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={tempConfig.showFooterCollections}
                              onChange={(e) => setTempConfig({ ...tempConfig, showFooterCollections: e.target.checked })}
                              className="rounded text-amber-600 focus:ring-amber-500"
                            />
                            <span className="font-semibold text-neutral-800">Show Collections Navigation Column</span>
                          </label>

                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={tempConfig.showFooterBrands}
                              onChange={(e) => setTempConfig({ ...tempConfig, showFooterBrands: e.target.checked })}
                              className="rounded text-amber-600 focus:ring-amber-500"
                            />
                            <span className="font-semibold text-neutral-800">Show Designer Brands Column</span>
                          </label>

                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={tempConfig.showFooterContact}
                              onChange={(e) => setTempConfig({ ...tempConfig, showFooterContact: e.target.checked })}
                              className="rounded text-amber-600 focus:ring-amber-500"
                            />
                            <span className="font-semibold text-neutral-800">Show Store Address & WhatsApp Column</span>
                          </label>

                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={tempConfig.showFooterPaymentLogos}
                              onChange={(e) => setTempConfig({ ...tempConfig, showFooterPaymentLogos: e.target.checked })}
                              className="rounded text-amber-600 focus:ring-amber-500"
                            />
                            <span className="font-semibold text-neutral-800">Show Payment & Courier Badges Strip</span>
                          </label>
                        </div>
                      </div>

                      {/* Store Address & Contact Settings */}
                      <div className="space-y-4 pt-2">
                        <div>
                          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                            Physical Store Address
                          </label>
                          <input
                            type="text"
                            value={tempConfig.storeAddress}
                            onChange={(e) => setTempConfig({ ...tempConfig, storeAddress: e.target.value })}
                            className="w-full px-3 py-2 border border-neutral-300 rounded text-xs font-medium"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Primary WhatsApp Helpline
                            </label>
                            <input
                              type="text"
                              value={tempConfig.whatsappNumber}
                              onChange={(e) => setTempConfig({ ...tempConfig, whatsappNumber: e.target.value })}
                              className="w-full px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Secondary WhatsApp / Phone Line
                            </label>
                            <input
                              type="text"
                              value={tempConfig.secondaryPhone || '+923014205395'}
                              onChange={(e) => setTempConfig({ ...tempConfig, secondaryPhone: e.target.value })}
                              className="w-full px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-semibold"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Official Customer Support Email
                            </label>
                            <input
                              type="email"
                              value={tempConfig.supportEmail}
                              onChange={(e) => setTempConfig({ ...tempConfig, supportEmail: e.target.value })}
                              className="w-full px-3 py-2 border border-neutral-300 rounded text-xs font-medium"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-neutral-700 mb-1">
                              Footer Copyright Notice Text
                            </label>
                            <input
                              type="text"
                              value={tempConfig.copyrightText}
                              onChange={(e) => setTempConfig({ ...tempConfig, copyrightText: e.target.value })}
                              className="w-full px-3 py-2 border border-neutral-300 rounded text-xs font-medium"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* SUBSECTION 6: COD & DELIVERY POLICIES */}
                  {customizerSubTab === 'policies' && (
                    <div className="bg-white p-6 rounded-xl border border-neutral-200 space-y-6">
                      <div className="border-b pb-4">
                        <h4 className="font-heading text-sm font-bold text-neutral-900">
                          Cash on Delivery (COD) & Shipping Configuration
                        </h4>
                        <p className="text-xs text-neutral-500">
                          Manage Cash on Delivery payment option, customer badges, and free shipping thresholds.
                        </p>
                      </div>

                      <div className="p-4 bg-emerald-50/60 rounded-xl border border-emerald-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h5 className="text-xs font-bold text-emerald-950 uppercase tracking-wider">
                              Cash on Delivery (COD) Checkout Option
                            </h5>
                            <p className="text-[11px] text-emerald-800">
                              Allow customers across Pakistan to pay cash when courier delivers parcel.
                            </p>
                          </div>

                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={tempConfig.enableCOD}
                              onChange={(e) => setTempConfig({ ...tempConfig, enableCOD: e.target.checked })}
                              className="sr-only peer"
                            />
                            <div className="w-9 h-5 bg-neutral-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                            <span className="ml-2 text-xs font-bold text-emerald-900">
                              {tempConfig.enableCOD ? 'COD Enabled' : 'Disabled'}
                            </span>
                          </label>
                        </div>

                        {tempConfig.enableCOD && (
                          <div>
                            <label className="block text-xs font-semibold text-emerald-900 mb-1">
                              COD Badge Label on Products & Hero
                            </label>
                            <input
                              type="text"
                              value={tempConfig.codBadgeText}
                              onChange={(e) => setTempConfig({ ...tempConfig, codBadgeText: e.target.value })}
                              className="w-full px-3 py-2 bg-white border border-emerald-300 rounded text-xs font-medium"
                            />
                          </div>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                        <div>
                          <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1">
                            Free Delivery Order Threshold (PKR)
                          </label>
                          <input
                            type="number"
                            value={tempConfig.freeDeliveryThresholdPKR}
                            onChange={(e) => setTempConfig({ ...tempConfig, freeDeliveryThresholdPKR: Number(e.target.value) })}
                            className="w-full px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-bold"
                          />
                          <span className="text-[10px] text-neutral-500 block mt-1">
                            Orders above this total receive free express courier delivery.
                          </span>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1">
                            Standard Courier Delivery Fee (PKR)
                          </label>
                          <input
                            type="number"
                            value={tempConfig.standardDeliveryFeePKR}
                            onChange={(e) => setTempConfig({ ...tempConfig, standardDeliveryFeePKR: Number(e.target.value) })}
                            className="w-full px-3 py-2 border border-neutral-300 rounded font-mono text-xs font-bold"
                          />
                          <span className="text-[10px] text-neutral-500 block mt-1">
                            Applied to orders below the free delivery threshold.
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Bottom Final Save & Publish Bar */}
                  <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
                    <button
                      type="button"
                      onClick={() => {
                        resetStoreConfig();
                        setTempConfig(storeConfig);
                      }}
                      className="px-4 py-2 text-xs font-semibold text-neutral-500 hover:text-neutral-900 underline cursor-pointer"
                    >
                      Revert All Settings to Initial Defaults
                    </button>

                    <div className="flex items-center gap-3">
                      {saveSuccess && (
                        <span className="text-xs text-emerald-700 font-bold flex items-center gap-1.5 animate-pulse">
                          <Check className="w-4 h-4 text-emerald-600" />
                          Final Changes Saved & Published!
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={handleSaveCustomization}
                        className="px-6 py-3 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold rounded-lg flex items-center gap-2 cursor-pointer shadow-lg transition-all transform hover:-translate-y-0.5"
                      >
                        <Save className="w-4 h-4 text-amber-400" />
                        <span>Save & Publish Final Changes</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: SALES & ANALYTICS */}
              {activeTab === 'analytics' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-white p-4 rounded-xl border border-neutral-200">
                      <div className="text-xs font-semibold text-neutral-500 mb-1">Total Sales Revenue</div>
                      <div className="text-2xl font-bold font-mono text-neutral-900 tabular-nums">
                        {formatPrice(totalRevenue)}
                      </div>
                      <div className="text-[11px] text-emerald-700 font-semibold mt-1">
                        Across {orders.length} orders
                      </div>
                    </div>

                    <div className="bg-white p-4 rounded-xl border border-neutral-200">
                      <div className="text-xs font-semibold text-neutral-500 mb-1">Average Order Value</div>
                      <div className="text-2xl font-bold font-mono text-neutral-900 tabular-nums">
                        {formatPrice(orders.length > 0 ? Math.round(totalRevenue / orders.length) : 0)}
                      </div>
                      <div className="text-[11px] text-neutral-500 mt-1">
                        High-tier unstitched designer suits
                      </div>
                    </div>

                    <div className="bg-white p-4 rounded-xl border border-neutral-200">
                      <div className="text-xs font-semibold text-neutral-500 mb-1">Total Suits in Catalog</div>
                      <div className="text-2xl font-bold font-mono text-neutral-900 tabular-nums">
                        {products.reduce((acc, p) => acc + p.stock, 0)} units
                      </div>
                      <div className="text-[11px] text-amber-700 font-semibold mt-1">
                        {products.length} distinct designer codes
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-xl border border-neutral-200">
                    <h4 className="font-heading text-sm font-bold text-neutral-900 mb-3">
                      Catalog Distribution by Original Brands
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      {['Saya', 'Khaadi', 'Sapphire', 'Nishat', 'Maria B', 'Asim Jofa', 'Sana Safinaz', 'Gul Ahmed'].map((brand) => {
                        const count = products.filter((p) => p.brand === brand).length;
                        return (
                          <div key={brand} className="p-3 bg-neutral-50 rounded-lg border border-neutral-200/80">
                            <span className="font-bold text-neutral-800 block">{brand}</span>
                            <span className="text-neutral-500">{count} suit articles available</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
