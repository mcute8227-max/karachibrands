import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  X, 
  Search, 
  Package, 
  CheckCircle, 
  Clock, 
  Truck, 
  MapPin, 
  AlertCircle,
  Banknote
} from 'lucide-react';
import { CustomerOrder } from '../types';

export const OrderTrackingModal: React.FC = () => {
  const { isOrderTrackingOpen, setOrderTrackingOpen, orders, formatPrice } = useStore();
  const [query, setQuery] = useState('');
  const [matchedOrder, setMatchedOrder] = useState<CustomerOrder | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  if (!isOrderTrackingOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
    const q = query.trim().toUpperCase();
    if (!q) {
      setMatchedOrder(null);
      return;
    }

    const cleanInput = query.trim().replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

    const found = orders.find((ord) => {
      const matchOrderNum = ord.orderNumber.toUpperCase().includes(q);
      const matchPhone = ord.phone.replace(/[^0-9]/g, '').includes(cleanInput);
      const matchTracking = ord.trackingNumber?.toUpperCase().includes(q);
      return matchOrderNum || matchPhone || matchTracking;
    });

    setMatchedOrder(found || null);
  };

  const getStepIndex = (status: CustomerOrder['orderStatus']) => {
    switch (status) {
      case 'Pending': return 1;
      case 'Processing': return 2;
      case 'Dispatched': return 3;
      case 'Delivered': return 4;
      case 'Cancelled': return 0;
      default: return 1;
    }
  };

  const currentStep = matchedOrder ? getStepIndex(matchedOrder.orderStatus) : 1;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        className="relative bg-white rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden border border-neutral-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-neutral-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-amber-400" />
            <h2 className="font-heading text-lg font-bold">Track Your Order Status</h2>
          </div>
          <button
            onClick={() => setOrderTrackingOpen(false)}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="mb-6">
            <label className="block text-xs font-semibold text-neutral-700 mb-1.5">
              Enter Order Number (e.g. KB-91823) or Mobile Phone
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-3 text-neutral-400" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="e.g. KB-91823, KB-91824 or 03218294711"
                  className="w-full pl-9 pr-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono uppercase focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  autoFocus
                />
              </div>
              <button
                type="submit"
                className="px-5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Track
              </button>
            </div>
            <div className="flex gap-2 text-[11px] text-neutral-500 mt-2">
              <span>Quick Test ID:</span>
              <button
                type="button"
                onClick={() => { setQuery('KB-91823'); }}
                className="text-amber-700 underline font-mono cursor-pointer"
              >
                KB-91823 (COD)
              </button>
              <button
                type="button"
                onClick={() => { setQuery('KB-91824'); }}
                className="text-amber-700 underline font-mono cursor-pointer"
              >
                KB-91824
              </button>
            </div>
          </form>

          {/* Results Display */}
          {matchedOrder ? (
            <div className="space-y-6">
              
              {/* Order Banner */}
              <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-200 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-[11px] text-neutral-500 font-semibold">Order Number</div>
                  <div className="font-mono text-base font-bold text-neutral-900">{matchedOrder.orderNumber}</div>
                  <div className="text-[11px] text-neutral-500">
                    Placed on {new Date(matchedOrder.createdAt).toLocaleDateString()}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[11px] text-neutral-500 font-semibold">Payment & Status</div>
                  <div className="flex items-center gap-1.5 justify-end">
                    <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                      {matchedOrder.paymentMethod === 'COD' ? 'Cash on Delivery' : matchedOrder.paymentMethod}
                    </span>
                    <span className={`inline-block px-2.5 py-0.5 rounded text-xs font-bold uppercase ${
                      matchedOrder.orderStatus === 'Delivered'
                        ? 'bg-emerald-100 text-emerald-800'
                        : matchedOrder.orderStatus === 'Dispatched'
                        ? 'bg-blue-100 text-blue-800'
                        : matchedOrder.orderStatus === 'Processing'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-neutral-200 text-neutral-800'
                    }`}>
                      {matchedOrder.orderStatus}
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-600 font-mono mt-0.5">
                    {matchedOrder.courierName}: {matchedOrder.trackingNumber}
                  </div>
                </div>
              </div>

              {/* 4-Step Progress Timeline */}
              {matchedOrder.orderStatus !== 'Cancelled' ? (
                <div className="py-2">
                  <div className="grid grid-cols-4 gap-2 text-center relative">
                    <div className="absolute top-4 left-6 right-6 h-0.5 bg-neutral-200 -z-0" />
                    <div 
                      className="absolute top-4 left-6 h-0.5 bg-amber-600 transition-all duration-500 -z-0" 
                      style={{ width: `${((currentStep - 1) / 3) * 100}%` }}
                    />

                    {/* Step 1 */}
                    <div className="flex flex-col items-center relative z-10">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        currentStep >= 1 ? 'bg-amber-600 text-white shadow-sm' : 'bg-neutral-200 text-neutral-600'
                      }`}>
                        1
                      </div>
                      <span className="text-[11px] font-semibold text-neutral-900 mt-2">Order Confirmed</span>
                      <span className="text-[10px] text-neutral-500">Verified</span>
                    </div>

                    {/* Step 2 */}
                    <div className="flex flex-col items-center relative z-10">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        currentStep >= 2 ? 'bg-amber-600 text-white shadow-sm' : 'bg-neutral-200 text-neutral-600'
                      }`}>
                        2
                      </div>
                      <span className="text-[11px] font-semibold text-neutral-900 mt-2">Quality Inspection</span>
                      <span className="text-[10px] text-neutral-500">Original suit checked</span>
                    </div>

                    {/* Step 3 */}
                    <div className="flex flex-col items-center relative z-10">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        currentStep >= 3 ? 'bg-amber-600 text-white shadow-sm' : 'bg-neutral-200 text-neutral-600'
                      }`}>
                        3
                      </div>
                      <span className="text-[11px] font-semibold text-neutral-900 mt-2">Dispatched</span>
                      <span className="text-[10px] text-neutral-500">{matchedOrder.courierName?.split(' ')[0] || 'Courier'}</span>
                    </div>

                    {/* Step 4 */}
                    <div className="flex flex-col items-center relative z-10">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        currentStep >= 4 ? 'bg-emerald-600 text-white shadow-sm' : 'bg-neutral-200 text-neutral-600'
                      }`}>
                        4
                      </div>
                      <span className="text-[11px] font-semibold text-neutral-900 mt-2">Delivered</span>
                      <span className="text-[10px] text-neutral-500">At Doorstep</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>This order has been cancelled. Please contact customer support on WhatsApp for queries.</span>
                </div>
              )}

              {/* Items & Shipping Address details */}
              <div className="border-t border-neutral-200 pt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <h4 className="font-bold text-neutral-900 mb-1 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-neutral-500" />
                    Delivery Destination
                  </h4>
                  <p className="text-neutral-700 font-medium">{matchedOrder.customerName}</p>
                  <p className="text-neutral-600">{matchedOrder.address}</p>
                  <p className="text-neutral-600">{matchedOrder.city} {matchedOrder.postalCode}</p>
                </div>

                <div>
                  <h4 className="font-bold text-neutral-900 mb-1 flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5 text-neutral-500" />
                    Suit Articles in Parcel ({matchedOrder.items.length})
                  </h4>
                  <div className="space-y-1">
                    {matchedOrder.items.map((it, idx) => (
                      <div key={idx} className="text-neutral-700">
                        <span className="font-semibold text-neutral-900">{it.brand}</span>: {it.productTitle} ({it.pieces}) × {it.quantity}
                      </div>
                    ))}
                  </div>
                  <div className="mt-2 font-bold text-neutral-900">
                    Payable: {formatPrice(matchedOrder.total)} ({matchedOrder.paymentMethod === 'COD' ? 'Cash on Delivery' : matchedOrder.paymentMethod})
                  </div>
                </div>
              </div>

            </div>
          ) : hasSearched ? (
            <div className="text-center py-8 bg-neutral-50 rounded-xl border border-neutral-200">
              <AlertCircle className="w-8 h-8 text-neutral-400 mx-auto mb-2" />
              <h4 className="font-bold text-neutral-800 text-sm">No Order Found</h4>
              <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                No matching order was found for "{query}". Please check your order confirmation SMS or contact Karachi Brands support.
              </p>
            </div>
          ) : null}

        </div>
      </div>
    </div>
  );
};
