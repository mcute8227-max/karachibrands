import React from 'react';
import { useStore } from '../context/StoreContext';
import { MessageCircle } from 'lucide-react';

export const WhatsAppFloatingButton: React.FC = () => {
  const { storeConfig } = useStore();

  const handleWhatsAppClick = () => {
    let cleanNumber = storeConfig.whatsappNumber.replace(/[^0-9]/g, '');
    if (cleanNumber.startsWith('0')) {
      cleanNumber = '92' + cleanNumber.slice(1);
    }
    const msg = encodeURIComponent(
      `Hello ${storeConfig.brandName}! I am interested in ordering unstitched original designer suits from your online catalog. Please assist me.`
    );
    window.open(`https://wa.me/${cleanNumber}?text=${msg}`, '_blank');
  };

  return (
    <div className="fixed bottom-5 right-5 z-40">
      <button
        onClick={handleWhatsAppClick}
        aria-label="Chat on WhatsApp"
        className="group relative flex items-center justify-center w-12 h-12 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full shadow-lg hover:shadow-emerald-600/40 transition-all transform hover:scale-105 cursor-pointer focus:outline-none"
      >
        <MessageCircle className="w-6 h-6" />
        
        {/* Tooltip on hover */}
        <span className="hidden md:block absolute right-14 whitespace-nowrap bg-neutral-900 text-white text-[11px] font-medium py-1 px-2.5 rounded shadow-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          Order via WhatsApp
        </span>
      </button>
    </div>
  );
};
