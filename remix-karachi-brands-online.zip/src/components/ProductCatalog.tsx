import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCard } from './ProductCard';
import { CategoryType, FabricType } from '../types';
import { X, Search, Banknote } from 'lucide-react';

export const ProductCatalog: React.FC = () => {
  const { 
    products, 
    activeCategory, 
    setActiveCategory, 
    selectedBrand, 
    setSelectedBrand,
    searchQuery,
    setSearchQuery
  } = useStore();

  const [selectedFabric, setSelectedFabric] = useState<string>('All Fabrics');
  const [selectedPiece, setSelectedPiece] = useState<string>('All Pieces');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');

  const categories: CategoryType[] = [
    'All Collection',
    'New Arrivals',
    'Summer Collection',
    'Winter Collection',
    'Trending Articles',
    'Fancy Articles'
  ];

  const fabrics: FabricType[] = [
    'Lawn',
    'Chiffon',
    'Khaddar',
    'Pure Silk',
    'Velvet',
    'Organza',
    'Cambric',
    'Jacquard'
  ];

  // Filtering Logic
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Category filter
      if (activeCategory === 'New Arrivals' && !product.isNewArrival) return false;
      if (activeCategory === 'Summer Collection' && product.category !== 'Summer Collection') return false;
      if (activeCategory === 'Winter Collection' && product.category !== 'Winter Collection') return false;
      if (activeCategory === 'Trending Articles' && !product.isTrending) return false;
      if (activeCategory === 'Fancy Articles' && !product.isFancy) return false;

      // Brand filter
      if (selectedBrand !== 'All Brands' && product.brand !== selectedBrand) return false;

      // Fabric filter
      if (selectedFabric !== 'All Fabrics' && product.fabric !== selectedFabric) return false;

      // Piece count filter
      if (selectedPiece !== 'All Pieces' && product.pieces !== selectedPiece) return false;

      // Search Query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchTitle = product.title.toLowerCase().includes(query);
        const matchBrand = product.brand.toLowerCase().includes(query);
        const matchCode = product.code.toLowerCase().includes(query);
        const matchFabric = product.fabric.toLowerCase().includes(query);
        const matchDesc = product.description.toLowerCase().includes(query);
        if (!matchTitle && !matchBrand && !matchCode && !matchFabric && !matchDesc) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0;
    });
  }, [products, activeCategory, selectedBrand, selectedFabric, selectedPiece, searchQuery, sortBy]);

  const resetAllFilters = () => {
    setActiveCategory('All Collection');
    setSelectedBrand('All Brands');
    setSelectedFabric('All Fabrics');
    setSelectedPiece('All Pieces');
    setSearchQuery('');
    setSortBy('featured');
  };

  const hasActiveFilters = 
    activeCategory !== 'All Collection' || 
    selectedBrand !== 'All Brands' || 
    selectedFabric !== 'All Fabrics' || 
    selectedPiece !== 'All Pieces' ||
    searchQuery.trim() !== '';

  return (
    <section id="catalog-section" className="py-12 bg-neutral-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-neutral-200">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-700 tracking-wider uppercase mb-1">
              <span>Karachi Brands Catalog</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-700 flex items-center gap-1 font-bold">
                <Banknote className="w-3.5 h-3.5" />
                COD Enabled Nationwide
              </span>
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl font-bold text-neutral-900 tracking-tight">
              {activeCategory}
            </h2>
            <p className="text-sm text-neutral-500 mt-1">
              Showing {filteredProducts.length} authentic designer article{filteredProducts.length === 1 ? '' : 's'} with Cash on Delivery option
            </p>
          </div>

          {/* Quick Category Segmented Tabs */}
          <div className="mt-4 md:mt-0 flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            {categories.map((cat) => {
              const isActive = activeCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-all cursor-pointer ${
                    isActive
                      ? 'bg-neutral-900 text-amber-300 font-semibold shadow-sm'
                      : 'bg-white text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 border border-neutral-200'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Filter & Sorting Action Bar */}
        <div className="bg-white p-3 rounded-lg border border-neutral-200/90 shadow-xs mb-8 flex flex-wrap items-center justify-between gap-4">
          
          <div className="flex flex-wrap items-center gap-2">
            {/* Fabric Selector */}
            <select
              value={selectedFabric}
              onChange={(e) => setSelectedFabric(e.target.value)}
              className="bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-700 rounded-md px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              <option value="All Fabrics">All Fabrics</option>
              {fabrics.map((fab) => (
                <option key={fab} value={fab}>{fab}</option>
              ))}
            </select>

            {/* Pieces Selector */}
            <select
              value={selectedPiece}
              onChange={(e) => setSelectedPiece(e.target.value)}
              className="bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-700 rounded-md px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              <option value="All Pieces">All Pieces</option>
              <option value="3-Piece">3-Piece Unstitched</option>
              <option value="2-Piece">2-Piece Unstitched</option>
            </select>

            {/* Reset Filters button if filters applied */}
            {hasActiveFilters && (
              <button
                onClick={resetAllFilters}
                className="flex items-center gap-1 text-xs text-amber-700 hover:text-amber-800 font-medium px-2 py-1 rounded bg-amber-50 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
                <span>Reset Filters</span>
              </button>
            )}
          </div>

          {/* Sort By Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-neutral-500 font-medium hidden sm:inline">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-700 rounded-md px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              <option value="featured">Featured Collection</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>
        </div>

        {/* Product Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="bg-white border border-neutral-200 rounded-xl p-12 text-center max-w-lg mx-auto my-8">
            <div className="w-12 h-12 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4 text-neutral-400">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="font-heading text-lg font-bold text-neutral-900 mb-2">
              No Articles Found
            </h3>
            <p className="text-xs text-neutral-500 mb-6">
              We couldn't find any unstitched suits matching your active filters. Try resetting the filters or searching with a different brand or fabric name.
            </p>
            <button
              onClick={resetAllFilters}
              className="px-4 py-2 bg-neutral-900 text-white text-xs font-medium rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
