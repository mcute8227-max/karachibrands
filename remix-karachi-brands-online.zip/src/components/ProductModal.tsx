import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  X, 
  ShoppingBag, 
  Heart, 
  ShieldCheck, 
  Truck, 
  Check, 
  MessageCircle, 
  Scissors, 
  Banknote
} from 'lucide-react';

export const ProductModal: React.FC = () => {
  const { 
    selectedProduct, 
    setSelectedProduct, 
    formatPrice, 
    addToCart, 
    buyNowWithCOD,
    toggleWishlist, 
    isInWishlist,
    storeConfig
  } = useStore();

  const [quantity, setQuantity] = useState(1);
  const [addedAnimation, setAddedAnimation] = useState(false);

  if (!selectedProduct) return null;

  const inWishlist = isInWishlist(selectedProduct.id);

  const handleAddToCart = () => {
    addToCart(selectedProduct, quantity);
    setAddedAnimation(true);
    setTimeout(() => {
      setAddedAnimation(false);
      setSelectedProduct(null);
    }, 1200);
  };

  const handleBuyCOD = () => {
    buyNowWithCOD(selectedProduct, quantity);
  };

  const handleWhatsAppOrder = () => {
    const text = encodeURIComponent(
      `Hello Karachi Brands! I want to order this original unstitched suit via Cash on Delivery:\n\nBrand: ${selectedProduct.brand}\nArticle: ${selectedProduct.title}\nCode: ${selectedProduct.code}\nPieces: ${selectedProduct.pieces}\nPrice: ${formatPrice(selectedProduct.price)}\nQty: ${quantity}\n\nPlease confirm availability and delivery to my address.`
    );
    let cleanNumber = storeConfig.whatsappNumber.replace(/[^0-9]/g, '');
    if (cleanNumber.startsWith('0')) {
      cleanNumber = '92' + cleanNumber.slice(1);
    }
    window.open(`https://wa.me/${cleanNumber}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        className="relative bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col md:flex-row overflow-hidden border border-neutral-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Modal Button */}
        <button
          onClick={() => setSelectedProduct(null)}
          className="absolute top-3 right-3 z-20 p-2 rounded-full bg-white/90 hover:bg-neutral-100 text-neutral-600 hover:text-neutral-900 shadow-xs transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Column: Visual Showcase */}
        <div className="md:w-1/2 bg-neutral-100 relative min-h-[280px] sm:min-h-[380px] md:min-h-full flex items-center justify-center">
          <img
            src={selectedProduct.image}
            alt={selectedProduct.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center max-h-[460px] md:max-h-full"
          />

          <div className="absolute top-4 left-4 flex flex-col gap-1.5">
            <span className="bg-neutral-950/85 backdrop-blur-sm text-amber-300 text-xs font-semibold px-2.5 py-1 rounded">
              Original {selectedProduct.brand}
            </span>
            <span className="bg-white/90 backdrop-blur-sm text-neutral-800 text-[11px] font-medium px-2 py-0.5 rounded shadow-xs">
              Code: {selectedProduct.code}
            </span>
          </div>

          <button
            onClick={() => toggleWishlist(selectedProduct.id)}
            className="absolute bottom-4 left-4 p-2.5 rounded-full bg-white/90 backdrop-blur-sm text-neutral-600 hover:text-red-500 shadow-md transition-colors cursor-pointer"
            aria-label="Wishlist"
          >
            <Heart className={`w-5 h-5 ${inWishlist ? 'fill-red-500 text-red-500' : ''}`} />
          </button>
        </div>

        {/* Right Column: Contiguous Purchase Module */}
        <div className="md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto max-h-[60vh] md:max-h-[88vh]">
          <div>
            {/* Editorial Kicker */}
            <div className="flex items-center gap-2 text-xs text-neutral-500 mb-2">
              <span className="font-bold text-neutral-900 uppercase tracking-wider">{selectedProduct.brand}</span>
              <span aria-hidden="true">·</span>
              <span>{selectedProduct.category}</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-700 font-medium">In Stock ({selectedProduct.stock} Left)</span>
            </div>

            {/* Product Title */}
            <h1 className="font-heading text-xl sm:text-2xl font-bold text-neutral-900 leading-tight mb-3">
              {selectedProduct.title}
            </h1>

            {/* Price Row */}
            <div className="flex items-baseline gap-3 mb-5">
              <span className="text-2xl font-bold text-neutral-950 tabular-nums">
                {formatPrice(selectedProduct.price)}
              </span>
              {selectedProduct.originalPrice && selectedProduct.originalPrice > selectedProduct.price && (
                <span className="text-sm text-neutral-400 line-through tabular-nums">
                  {formatPrice(selectedProduct.originalPrice)}
                </span>
              )}
              {selectedProduct.originalPrice && (
                <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                  Save {Math.round(((selectedProduct.originalPrice - selectedProduct.price) / selectedProduct.originalPrice) * 100)}%
                </span>
              )}
            </div>

            {/* Description */}
            <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed mb-6">
              {selectedProduct.description}
            </p>

            {/* Unstitched Fabric Package Breakdown */}
            <div className="bg-neutral-50 rounded-lg p-3.5 border border-neutral-200/80 mb-6 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-900 uppercase tracking-wide mb-1">
                <Scissors className="w-3.5 h-3.5 text-amber-600" />
                <span>Unstitched Package Breakdown</span>
              </div>
              <div className="text-xs text-neutral-700 grid grid-cols-1 gap-1.5">
                <div className="flex items-start justify-between border-b border-neutral-200/60 pb-1">
                  <span className="text-neutral-500 font-medium">Shirt Fabric:</span>
                  <span className="text-right font-medium text-neutral-800">{selectedProduct.components.shirt}</span>
                </div>
                <div className="flex items-start justify-between border-b border-neutral-200/60 pb-1">
                  <span className="text-neutral-500 font-medium">Dupatta:</span>
                  <span className="text-right font-medium text-neutral-800">{selectedProduct.components.dupatta}</span>
                </div>
                <div className="flex items-start justify-between border-b border-neutral-200/60 pb-1">
                  <span className="text-neutral-500 font-medium">Trouser:</span>
                  <span className="text-right font-medium text-neutral-800">{selectedProduct.components.trouser}</span>
                </div>
                <div className="flex items-start justify-between pt-0.5">
                  <span className="text-neutral-500 font-medium">Work / Detail:</span>
                  <span className="text-right font-medium text-amber-800">{selectedProduct.components.embroidery}</span>
                </div>
              </div>
            </div>

            {/* Quantity Stepper & Stock */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center border border-neutral-300 rounded-lg overflow-hidden bg-white">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-3 py-2 text-neutral-600 hover:bg-neutral-100 font-medium cursor-pointer transition-colors"
                >
                  -
                </button>
                <span className="px-3 py-2 text-xs font-bold text-neutral-800 min-w-8 text-center tabular-nums">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.min(selectedProduct.stock, q + 1))}
                  className="px-3 py-2 text-neutral-600 hover:bg-neutral-100 font-medium cursor-pointer transition-colors"
                >
                  +
                </button>
              </div>

              <div className="text-xs text-neutral-500">
                <span>{selectedProduct.pieces} Unstitched Fabric Suit</span>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="space-y-2.5 pt-4 border-t border-neutral-200">
            {/* Primary Cash on Delivery Fast Checkout Button */}
            <button
              onClick={handleBuyCOD}
              disabled={selectedProduct.stock <= 0}
              className="w-full py-3.5 px-4 rounded-lg text-xs sm:text-sm font-bold bg-emerald-700 hover:bg-emerald-600 text-white flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md disabled:bg-neutral-300"
            >
              <Banknote className="w-4 h-4 text-emerald-200" />
              <span>Buy with Cash on Delivery (COD) · {formatPrice(selectedProduct.price * quantity)}</span>
            </button>

            {/* Standard Add to Bag button */}
            <button
              onClick={handleAddToCart}
              disabled={selectedProduct.stock <= 0}
              className={`w-full py-2.5 px-4 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                addedAnimation
                  ? 'bg-neutral-800 text-white'
                  : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-900 border border-neutral-300'
              }`}
            >
              {addedAnimation ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Added to Shopping Bag!</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3.5 h-3.5 text-neutral-700" />
                  <span>Add to Bag</span>
                </>
              )}
            </button>

            {/* Direct WhatsApp Order with 1-Click */}
            <button
              onClick={handleWhatsAppOrder}
              className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span>Order Instantly on WhatsApp</span>
            </button>

            {/* Quick Guarantees */}
            <div className="flex items-center justify-between text-[11px] text-neutral-500 pt-2">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                100% Original Brand
              </span>
              <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                <Banknote className="w-3.5 h-3.5 text-emerald-600" />
                Cash on Delivery Available
              </span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
