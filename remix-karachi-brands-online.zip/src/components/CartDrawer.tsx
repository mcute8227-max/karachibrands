import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { X, Trash2, ShoppingBag, ArrowRight, Tag, ShieldCheck, Banknote } from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setCartOpen,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    formatPrice,
    setCheckoutOpen,
    setDefaultPaymentMethod,
    storeConfig
  } = useStore();

  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState<{ code: string; discountPKR: number } | null>(null);
  const [couponError, setCouponError] = useState('');
  const [cartPaymentPreference, setCartPaymentPreference] = useState<'COD' | 'Card'>('COD');

  if (!isCartOpen) return null;

  const subtotalPKR = cart.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  const isFreeDelivery = subtotalPKR >= storeConfig.freeDeliveryThresholdPKR || subtotalPKR === 0;
  const deliveryFeePKR = isFreeDelivery ? 0 : storeConfig.standardDeliveryFeePKR;
  const remainingForFreeShipping = Math.max(0, storeConfig.freeDeliveryThresholdPKR - subtotalPKR);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    const code = couponCode.trim().toUpperCase();

    if (code === 'KARACHI10') {
      const discount = Math.round(subtotalPKR * 0.1);
      setCouponApplied({ code: 'KARACHI10 (10% OFF)', discountPKR: discount });
      setCouponCode('');
    } else if (code === 'WELCOME500') {
      setCouponApplied({ code: 'WELCOME500 (Rs. 500 OFF)', discountPKR: 500 });
      setCouponCode('');
    } else {
      setCouponError('Invalid coupon code. Try KARACHI10 or WELCOME500');
    }
  };

  const totalDiscountPKR = couponApplied ? couponApplied.discountPKR : 0;
  const grandTotalPKR = Math.max(0, subtotalPKR + deliveryFeePKR - totalDiscountPKR);

  const handleProceedToCheckout = (chosenPayment: 'COD' | 'Card') => {
    setDefaultPaymentMethod(chosenPayment);
    setCartOpen(false);
    setCheckoutOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-xs">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          
          {/* Header */}
          <div className="px-6 py-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/50">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-amber-600" />
              <h2 className="font-heading text-lg font-bold text-neutral-900">
                Shopping Bag ({cart.reduce((a, b) => a + b.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={() => setCartOpen(false)}
              className="p-1.5 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200/50 cursor-pointer transition-colors"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Meter */}
          {cart.length > 0 && (
            <div className="px-6 py-3 bg-amber-50/70 border-b border-amber-200/50 text-xs">
              {isFreeDelivery ? (
                <div className="text-emerald-700 font-semibold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Congratulations! You qualify for FREE Nationwide Delivery!</span>
                </div>
              ) : (
                <div>
                  <div className="flex justify-between text-neutral-700 font-medium mb-1">
                    <span>Add {formatPrice(remainingForFreeShipping)} more for FREE Delivery</span>
                    <span>{Math.round((subtotalPKR / storeConfig.freeDeliveryThresholdPKR) * 100)}%</span>
                  </div>
                  <div className="w-full bg-neutral-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-amber-600 h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, (subtotalPKR / storeConfig.freeDeliveryThresholdPKR) * 100)}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto px-6 py-4 divide-y divide-neutral-100">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mb-4 text-neutral-400">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="font-heading text-base font-bold text-neutral-800 mb-1">
                  Your bag is currently empty
                </h3>
                <p className="text-xs text-neutral-500 max-w-xs mb-6">
                  Explore original unstitched collections from Saya, Khaadi, Sapphire, and Maria B.
                </p>
                <button
                  onClick={() => setCartOpen(false)}
                  className="px-5 py-2.5 bg-neutral-900 text-white text-xs font-semibold rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div key={item.product.id} className="py-4 flex gap-4 items-center">
                  <img
                    src={item.product.image}
                    alt={item.product.title}
                    referrerPolicy="no-referrer"
                    className="w-16 h-20 object-cover rounded-md bg-neutral-100 shrink-0 border border-neutral-200"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 text-[10px] text-neutral-500 uppercase font-semibold">
                      <span>{item.product.brand}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.product.pieces}</span>
                    </div>
                    <h4 className="text-xs font-semibold text-neutral-900 truncate">
                      {item.product.title}
                    </h4>
                    <p className="text-[11px] text-neutral-500 font-mono">
                      {item.product.code}
                    </p>

                    <div className="mt-2 flex items-center justify-between">
                      {/* Stepper */}
                      <div className="flex items-center border border-neutral-200 rounded bg-white">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                          className="px-2 py-0.5 text-xs text-neutral-600 hover:bg-neutral-100 cursor-pointer"
                        >
                          -
                        </button>
                        <span className="px-2 text-xs font-semibold text-neutral-800 tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                          className="px-2 py-0.5 text-xs text-neutral-600 hover:bg-neutral-100 cursor-pointer"
                        >
                          +
                        </button>
                      </div>

                      <div className="text-right">
                        <div className="text-xs font-bold text-neutral-900 tabular-nums">
                          {formatPrice(item.product.price * item.quantity)}
                        </div>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="p-1 text-neutral-400 hover:text-red-500 transition-colors cursor-pointer"
                    aria-label="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Bottom Summary Section */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-neutral-200 bg-neutral-50/70 space-y-3">
              
              {/* Option to Select Payment Mode in Cart */}
              <div className="bg-white p-2.5 rounded-lg border border-neutral-200 space-y-1.5">
                <span className="text-[11px] font-bold text-neutral-700 block uppercase tracking-wider">
                  Select Payment Preference:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCartPaymentPreference('COD')}
                    className={`py-2 px-2.5 rounded-md text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      cartPaymentPreference === 'COD'
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200 border border-neutral-200'
                    }`}
                  >
                    <Banknote className="w-3.5 h-3.5" />
                    <span>Cash on Delivery (COD)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCartPaymentPreference('Card')}
                    className={`py-2 px-2.5 rounded-md text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      cartPaymentPreference === 'Card'
                        ? 'bg-neutral-900 text-white shadow-xs'
                        : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200 border border-neutral-200'
                    }`}
                  >
                    <span>Card / Online</span>
                  </button>
                </div>
              </div>

              {/* Coupon Form */}
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-400" />
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="Promo code (e.g. KARACHI10)"
                    className="w-full pl-8 pr-3 py-1.5 bg-white border border-neutral-300 rounded-md text-xs uppercase text-neutral-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-medium rounded-md cursor-pointer transition-colors"
                >
                  Apply
                </button>
              </form>

              {couponError && (
                <p className="text-[11px] text-red-600">{couponError}</p>
              )}

              {couponApplied && (
                <div className="flex items-center justify-between text-xs text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded">
                  <span>{couponApplied.code}</span>
                  <button 
                    onClick={() => setCouponApplied(null)} 
                    className="text-neutral-500 hover:text-neutral-800 font-semibold cursor-pointer"
                  >
                    Remove
                  </button>
                </div>
              )}

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-neutral-600 pt-2 border-t border-neutral-200/80">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-neutral-900 tabular-nums">{formatPrice(subtotalPKR)}</span>
                </div>

                <div className="flex justify-between">
                  <span>Delivery Charges</span>
                  <span className="font-semibold tabular-nums">
                    {deliveryFeePKR === 0 ? (
                      <span className="text-emerald-700 font-bold">FREE</span>
                    ) : (
                      formatPrice(deliveryFeePKR)
                    )}
                  </span>
                </div>

                {totalDiscountPKR > 0 && (
                  <div className="flex justify-between text-amber-700">
                    <span>Discount</span>
                    <span className="font-semibold tabular-nums">-{formatPrice(totalDiscountPKR)}</span>
                  </div>
                )}

                <div className="flex justify-between text-sm font-bold text-neutral-950 pt-2 border-t border-neutral-200">
                  <span>Total Payable</span>
                  <span className="tabular-nums">{formatPrice(grandTotalPKR)}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <button
                onClick={() => handleProceedToCheckout(cartPaymentPreference)}
                className={`w-full py-3 px-4 font-bold text-xs sm:text-sm rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                  cartPaymentPreference === 'COD'
                    ? 'bg-emerald-700 hover:bg-emerald-600 text-white'
                    : 'bg-amber-600 hover:bg-amber-500 text-neutral-950'
                }`}
              >
                {cartPaymentPreference === 'COD' ? (
                  <>
                    <Banknote className="w-4 h-4 text-white" />
                    <span>Checkout with Cash on Delivery (COD)</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                ) : (
                  <>
                    <span>Proceed to Card Checkout</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="text-center">
                <button
                  onClick={clearCart}
                  className="text-[11px] text-neutral-400 hover:text-neutral-600 cursor-pointer"
                >
                  Clear Bag
                </button>
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
};
