import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  ShoppingBag, 
  Heart, 
  Search, 
  Package, 
  ShieldCheck, 
  Lock, 
  Menu, 
  X,
  ChevronDown
} from 'lucide-react';
import { CurrencyCode } from '../types';

export const Navbar: React.FC = () => {
  const {
    storeConfig,
    cart,
    wishlist,
    activeCurrency,
    setCurrency,
    setCartOpen,
    setOrderTrackingOpen,
    setAdminDashboardOpen,
    setActiveCategory,
    activeCategory,
    setSearchQuery,
    searchQuery
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSearchInput, setShowSearchInput] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);
  const currencies: CurrencyCode[] = ['PKR', 'USD', 'GBP', 'AED', 'SAR', 'CAD'];

  const totalCartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navCategories = storeConfig.navLinks && storeConfig.navLinks.length > 0 
    ? storeConfig.navLinks 
    : [
        'All Collection',
        'New Arrivals',
        'Summer Collection',
        'Winter Collection',
        'Trending Articles',
        'Fancy Articles'
      ];

  const logoDimension = storeConfig.logoSize === 'large' 
    ? 'w-14 h-14' 
    : storeConfig.logoSize === 'small' 
    ? 'w-9 h-9' 
    : 'w-11 h-11';

  return (
    <header 
      className="sticky top-0 z-40 w-full backdrop-blur-md border-b border-neutral-200 transition-colors"
      style={{ backgroundColor: storeConfig.headerBgColor || '#ffffff', color: storeConfig.headerTextColor || '#0f172a' }}
    >
      {/* Top Announcement Bar */}
      {storeConfig.showAnnouncement && (
        <div 
          className="text-xs py-2 px-4 text-center font-medium tracking-wide flex items-center justify-between transition-colors"
          style={{ backgroundColor: storeConfig.announcementBgColor || '#0f172a', color: storeConfig.announcementTextColor || '#fde047' }}
        >
          <div className="w-full text-center truncate">
            {storeConfig.announcementText}
          </div>
        </div>
      )}

      {/* Main Navigation Bar (Complies with Top Bar Contract: 3 Zones separated by gap-8) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          
          {/* Zone 1: Brand Logo & Wordmark */}
          <button 
            onClick={() => {
              setActiveCategory('All Collection');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-left cursor-pointer group flex items-center gap-3 shrink-0 whitespace-nowrap focus:outline-none"
          >
            <div className={`relative ${logoDimension} rounded-lg overflow-hidden border border-neutral-800/20 bg-neutral-900 shadow-md group-hover:scale-105 transition-all flex items-center justify-center shrink-0`}>
              <img
                src={storeConfig.logoUrl || '/assets/aistudio/Gemini_Generated_Image_l5ybrzl5ybrzl5yb_6cf03367.jpg'}
                alt="Karachi Brands Logo"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center"
              />
            </div>
            <div>
              <span 
                className="font-heading text-xl sm:text-2xl font-bold tracking-wider group-hover:opacity-80 transition-colors"
                style={{ color: storeConfig.headerTextColor || '#0f172a' }}
              >
                {storeConfig.brandName}
              </span>
              <span className="block text-[10px] tracking-widest text-neutral-500 uppercase font-sans -mt-1">
                {storeConfig.tagline || 'Original Unstitched'}
              </span>
            </div>
          </button>

          {/* Zone 2: Clean 4–5 Single-Line Nav Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium">
            {navCategories.slice(0, 5).map((category) => {
              const isActive = activeCategory === category;
              return (
                <button
                  key={category}
                  onClick={() => {
                    setActiveCategory(category);
                    const catalogEl = document.getElementById('catalog-section');
                    if (catalogEl) {
                      catalogEl.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className={`cursor-pointer whitespace-nowrap shrink-0 transition-colors relative py-1 focus:outline-none ${
                    isActive
                      ? 'font-bold'
                      : 'opacity-75 hover:opacity-100'
                  }`}
                  style={{ color: isActive ? storeConfig.accentColor || '#d97706' : storeConfig.headerTextColor || '#0f172a' }}
                >
                  {category}
                  {isActive && (
                    <span 
                      className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full" 
                      style={{ backgroundColor: storeConfig.accentColor || '#d97706' }}
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary Action & Utility Controls */}
          <div className="flex items-center gap-3 shrink-0">
            
            {/* Inline Quick Search Button / Input */}
            <div className="relative hidden sm:block">
              {showSearchInput ? (
                <div className="flex items-center bg-neutral-100 rounded-full px-3 py-1.5 border border-neutral-300">
                  <Search className="w-4 h-4 text-neutral-500 mr-2 shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search brand, lawn, code..."
                    className="bg-transparent text-xs text-neutral-800 focus:outline-none w-36 lg:w-48"
                    autoFocus
                  />
                  <button 
                    onClick={() => {
                      setShowSearchInput(false);
                      setSearchQuery('');
                    }}
                    className="text-neutral-400 hover:text-neutral-600 ml-1 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowSearchInput(true)}
                  aria-label="Search articles"
                  className="p-2 text-neutral-700 hover:text-amber-700 hover:bg-neutral-100 rounded-full transition-colors cursor-pointer"
                  title="Search products"
                >
                  <Search className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Currency Selector */}
            <div className="relative">
              <button
                onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-md border border-neutral-200 cursor-pointer"
              >
                <span>{activeCurrency}</span>
                <ChevronDown className="w-3 h-3 text-neutral-500" />
              </button>

              {currencyDropdownOpen && (
                <div className="absolute right-0 mt-2 w-28 bg-white border border-neutral-200 rounded-lg shadow-xl py-1 z-50">
                  {currencies.map((curr) => (
                    <button
                      key={curr}
                      onClick={() => {
                        setCurrency(curr);
                        setCurrencyDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 text-xs font-medium cursor-pointer hover:bg-neutral-50 transition-colors ${
                        activeCurrency === curr ? 'text-amber-700 font-bold bg-amber-50/60' : 'text-neutral-700'
                      }`}
                    >
                      {curr}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Track Order Button */}
            <button
              onClick={() => setOrderTrackingOpen(true)}
              className="p-2 text-neutral-700 hover:text-amber-700 hover:bg-neutral-100 rounded-full transition-colors cursor-pointer"
              title="Track Your Order"
              aria-label="Track Your Order"
            >
              <Package className="w-5 h-5" />
            </button>

            {/* Shopping Bag Button (Zone 3 Primary CTA) */}
            <button
              onClick={() => setCartOpen(true)}
              className="relative flex items-center gap-2 px-3.5 py-2 bg-neutral-900 text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer shadow-sm"
              aria-label="Shopping Bag"
            >
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline text-xs font-medium">Bag</span>
              {totalCartCount > 0 && (
                <span className="inline-flex items-center justify-center w-5 h-5 text-[11px] font-bold text-neutral-900 bg-amber-400 rounded-full">
                  {totalCartCount}
                </span>
              )}
            </button>

            {/* Admin Dashboard Access */}
            <button
              onClick={() => setAdminDashboardOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-neutral-600 hover:text-neutral-900 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors cursor-pointer border border-neutral-200/60"
              title="Admin Portal (Inventory, Theme & Orders)"
            >
              <Lock className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden md:inline">Admin</span>
            </button>

            {/* Mobile Hamburger Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-neutral-700 hover:bg-neutral-100 rounded-lg cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-neutral-200 px-4 py-4 space-y-3">
          {/* Mobile Search */}
          <div className="flex items-center bg-neutral-100 rounded-lg px-3 py-2 border border-neutral-200">
            <Search className="w-4 h-4 text-neutral-500 mr-2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search unstitched suits..."
              className="bg-transparent text-sm text-neutral-800 focus:outline-none w-full"
            />
          </div>

          <div className="pt-2 pb-1 text-xs font-bold text-neutral-400 uppercase tracking-wider">
            Collections
          </div>

          <div className="grid grid-cols-2 gap-2">
            {navCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setActiveCategory(cat);
                  setMobileMenuOpen(false);
                  const el = document.getElementById('catalog-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`text-left px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeCategory === cat
                    ? 'bg-amber-50 text-amber-800 font-semibold'
                    : 'text-neutral-700 hover:bg-neutral-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-neutral-200 flex items-center justify-between">
            <button
              onClick={() => {
                setOrderTrackingOpen(true);
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 text-sm text-neutral-700 font-medium py-1"
            >
              <Package className="w-4 h-4 text-neutral-500" />
              Track Customer Order
            </button>

            <button
              onClick={() => {
                setAdminDashboardOpen(true);
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-xs text-amber-700 font-semibold py-1 px-3 bg-amber-50 rounded"
            >
              <Lock className="w-3.5 h-3.5" />
              Admin Access
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
