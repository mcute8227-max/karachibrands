import React, { useState } from 'react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';
import { ShoppingBag, Eye, Heart, Check, Sparkles, Banknote } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { 
    formatPrice, 
    addToCart, 
    buyNowWithCOD,
    setSelectedProduct, 
    toggleWishlist, 
    isInWishlist 
  } = useStore();

  const [imgError, setImgError] = useState(false);
  const [justAdded, setJustAdded] = useState(false);
  const inWishlist = isInWishlist(product.id);

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1500);
  };

  const handleQuickCOD = (e: React.MouseEvent) => {
    e.stopPropagation();
    buyNowWithCOD(product, 1);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  const discountPercent = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div 
      onClick={() => setSelectedProduct(product)}
      className="group flex flex-col bg-white rounded-lg border border-neutral-200/90 overflow-hidden hover:shadow-md hover:border-neutral-300 transition-all duration-200 cursor-pointer"
    >
      {/* Product Image Stage */}
      <div className="relative aspect-[4/3] bg-neutral-100 overflow-hidden">
        {!imgError ? (
          <img
            src={product.image}
            alt={`${product.brand} - ${product.title}`}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gradient-to-br from-neutral-100 to-neutral-200 text-neutral-600">
            <Sparkles className="w-8 h-8 text-amber-500 mb-2 opacity-60" />
            <span className="text-xs font-semibold text-neutral-800">{product.brand}</span>
            <span className="text-[11px] text-neutral-500 text-center line-clamp-1">{product.title}</span>
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={handleWishlist}
          aria-label="Save to Wishlist"
          className="absolute top-2.5 right-2.5 p-2 rounded-full bg-white/90 backdrop-blur-sm text-neutral-600 hover:text-red-500 hover:bg-white shadow-sm transition-colors cursor-pointer"
        >
          <Heart 
            className={`w-4 h-4 transition-transform ${inWishlist ? 'fill-red-500 text-red-500 scale-110' : ''}`} 
          />
        </button>

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start">
          {discountPercent > 0 && (
            <span className="bg-neutral-900/90 backdrop-blur-sm text-amber-300 text-[10px] font-semibold tracking-wide px-2 py-0.5 rounded">
              Save {discountPercent}%
            </span>
          )}
          <span className="bg-emerald-900/90 backdrop-blur-sm text-emerald-200 text-[10px] font-semibold tracking-wide px-1.5 py-0.5 rounded flex items-center gap-1">
            <Banknote className="w-3 h-3" />
            COD
          </span>
        </div>

        {/* Quick Actions on Hover */}
        <div className="absolute inset-x-2 bottom-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1.5">
          <button
            onClick={handleQuickCOD}
            className="flex-1 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white text-[11px] font-bold rounded backdrop-blur-sm flex items-center justify-center gap-1 shadow-sm transition-colors cursor-pointer"
            title="Fast Checkout with Cash on Delivery"
          >
            <Banknote className="w-3 h-3" />
            <span>Order COD</span>
          </button>
          
          <button
            onClick={(e) => {
              e.stopPropagation();
              setSelectedProduct(product);
            }}
            className="px-2.5 py-1.5 bg-neutral-900/90 hover:bg-neutral-900 text-white text-[11px] font-medium rounded backdrop-blur-sm flex items-center justify-center gap-1 shadow-sm transition-colors cursor-pointer"
            title="Quick View Details"
          >
            <Eye className="w-3 h-3 text-amber-400" />
            <span>View</span>
          </button>
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-4 flex flex-col flex-1 justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-500 mb-1">
            <span className="font-semibold text-neutral-800 tracking-wider uppercase text-[11px]">{product.brand}</span>
            <span aria-hidden="true">·</span>
            <span>{product.pieces}</span>
            <span aria-hidden="true">·</span>
            <span>{product.fabric}</span>
          </div>

          <h3 className="text-sm font-semibold text-neutral-900 line-clamp-1 group-hover:text-amber-800 transition-colors">
            {product.title}
          </h3>

          <p className="text-[11px] text-neutral-500 mt-1 line-clamp-1">
            {product.dupattaFabric}
          </p>
        </div>

        {/* Price & Action Bottom Strip */}
        <div className="mt-3 pt-3 border-t border-neutral-100 flex items-center justify-between">
          <div>
            <div className="text-base font-bold text-neutral-900 tabular-nums">
              {formatPrice(product.price)}
            </div>
            {product.originalPrice && product.originalPrice > product.price && (
              <div className="text-xs text-neutral-400 line-through tabular-nums">
                {formatPrice(product.originalPrice)}
              </div>
            )}
          </div>

          <button
            onClick={handleAdd}
            disabled={product.stock <= 0}
            className={`cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
              product.stock <= 0
                ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                : justAdded
                ? 'bg-emerald-700 text-white'
                : 'bg-neutral-900 text-white hover:bg-amber-700'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added</span>
              </>
            ) : product.stock <= 0 ? (
              <span>Sold Out</span>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
                <span>Add</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
