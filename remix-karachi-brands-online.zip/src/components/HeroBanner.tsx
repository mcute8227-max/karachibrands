import React from 'react';
import { useStore } from '../context/StoreContext';
import { ShieldCheck, Truck, Sparkles, RefreshCw, ArrowRight, Banknote } from 'lucide-react';

export const HeroBanner: React.FC = () => {
  const { storeConfig, setActiveCategory } = useStore();

  const scrollToCatalog = (cat?: string) => {
    if (cat) setActiveCategory(cat);
    const catalog = document.getElementById('catalog-section');
    if (catalog) {
      catalog.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative overflow-hidden bg-neutral-900 text-white">
      {/* Background Graphic Image with Measured Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={storeConfig.bannerImageUrl || "/src/assets/images/hero_luxury_lawn_1793371043902.jpg"}
          alt={`${storeConfig.brandName} Luxury Unstitched Lawn Collection`}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-top brightness-90 filter"
        />
        {/* Measured Scrim for legibility and luxury depth */}
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-950/90 via-neutral-950/65 to-neutral-900/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-black/30" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-28">
        <div className="max-w-2xl">
          
          {/* Subtle Editorial Kicker */}
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest text-amber-300 uppercase mb-4">
            <span>Original Pakistani Designer Wear</span>
            <span aria-hidden="true">·</span>
            <span>Unstitched Masterpieces</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-bold">COD Available</span>
          </div>

          {/* Main Headline */}
          <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-tight mb-5 text-balance">
            {storeConfig.bannerHeadline}
          </h1>

          {/* Subtitle Description */}
          <p className="text-base sm:text-lg text-neutral-200 font-sans font-normal leading-relaxed mb-8 max-w-xl">
            {storeConfig.bannerSubheadline}
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={() => scrollToCatalog('Summer Collection')}
              className="cursor-pointer inline-flex items-center gap-2 px-6 py-3.5 bg-amber-600 hover:bg-amber-500 text-neutral-950 font-semibold text-sm rounded-lg shadow-lg hover:shadow-amber-600/30 transition-all transform hover:-translate-y-0.5"
            >
              <span>{storeConfig.bannerPrimaryBtnText || 'Explore Summer Lawn'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => scrollToCatalog('Fancy Articles')}
              className="cursor-pointer inline-flex items-center gap-2 px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-medium text-sm rounded-lg backdrop-blur-md border border-white/20 transition-all"
            >
              <span>{storeConfig.bannerSecondaryBtnText || 'Festive & Fancy Suits'}</span>
            </button>
          </div>

          {/* Live Brands Mention */}
          <div className="mt-10 pt-6 border-t border-white/15 flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-neutral-300 font-medium">
            <span className="text-amber-400 font-semibold">Authorized Original Stock:</span>
            <span>Saya</span>
            <span aria-hidden="true">·</span>
            <span>Khaadi</span>
            <span aria-hidden="true">·</span>
            <span>Sapphire</span>
            <span aria-hidden="true">·</span>
            <span>Nishat</span>
            <span aria-hidden="true">·</span>
            <span>Maria B</span>
            <span aria-hidden="true">·</span>
            <span>Asim Jofa</span>
          </div>
        </div>
      </div>

      {/* 4 Trust Value Pillars Strip */}
      {storeConfig.showTrustPillars !== false && (
        <div className="relative z-10 bg-neutral-950/80 backdrop-blur-md border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-neutral-300">
              
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">100% Original Brand</h4>
                  <p className="text-[11px] text-neutral-400">{storeConfig.pillar1Text || 'Saya, Khaadi, Sapphire & more'}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                  <Banknote className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">Cash on Delivery (COD)</h4>
                  <p className="text-[11px] text-emerald-300 font-medium">{storeConfig.pillar2Text || 'Pay courier upon parcel arrival'}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                  <Truck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">Fast Home Delivery</h4>
                  <p className="text-[11px] text-neutral-400">{storeConfig.pillar3Text || 'Sheikhupura & Nationwide'}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                  <RefreshCw className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">7-Day Easy Exchange</h4>
                  <p className="text-[11px] text-neutral-400">{storeConfig.pillar4Text || 'Hassle-free replacement policy'}</p>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
};
