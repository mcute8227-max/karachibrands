import React from 'react';
import { useStore } from '../context/StoreContext';

export const BrandBar: React.FC = () => {
  const { selectedBrand, setSelectedBrand } = useStore();

  const brands = [
    'All Brands',
    'Saya',
    'Khaadi',
    'Sapphire',
    'Nishat',
    'Maria B',
    'Asim Jofa',
    'Sana Safinaz',
    'Gul Ahmed'
  ];

  return (
    <div className="bg-neutral-100/70 border-b border-neutral-200 py-3">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth">
          <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider shrink-0 mr-2">
            Brands:
          </span>
          {brands.map((brand) => {
            const isSelected = selectedBrand === brand;
            return (
              <button
                key={brand}
                onClick={() => setSelectedBrand(brand)}
                className={`cursor-pointer whitespace-nowrap px-3.5 py-1.5 text-xs font-medium rounded-md transition-all shrink-0 ${
                  isSelected
                    ? 'bg-neutral-900 text-amber-300 font-semibold shadow-sm'
                    : 'bg-white text-neutral-700 hover:bg-neutral-200/80 border border-neutral-200'
                }`}
              >
                {brand}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
