import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  X, 
  ShieldCheck, 
  CreditCard, 
  Truck, 
  Smartphone, 
  CheckCircle2, 
  Lock, 
  Printer, 
  Banknote,
  AlertCircle
} from 'lucide-react';
import { CustomerOrder } from '../types';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setCheckoutOpen,
    cart,
    formatPrice,
    createOrder,
    storeConfig,
    defaultPaymentMethod
  } = useStore();

  const [step, setStep] = useState<'form' | 'otp' | 'success'>('form');

  // Customer Form Fields
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Karachi');
  const [postalCode, setPostalCode] = useState('');
  const [notes, setNotes] = useState('');
  
  // Payment Method - defaults to COD
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'Card' | 'JazzCash' | 'EasyPaisa' | 'BankTransfer' | 'WhatsApp'>('COD');

  useEffect(() => {
    if (defaultPaymentMethod) {
      setPaymentMethod(defaultPaymentMethod);
    }
  }, [defaultPaymentMethod, isCheckoutOpen]);
  
  // Card details
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardName, setCardName] = useState('');
  
  // Mobile Wallet / Bank details
  const [walletTransactionId, setWalletTransactionId] = useState('');
  
  // Card OTP verification state
  const [otpCode, setOtpCode] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<CustomerOrder | null>(null);

  if (!isCheckoutOpen) return null;

  const subtotalPKR = cart.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );
  const isFreeDelivery = subtotalPKR >= storeConfig.freeDeliveryThresholdPKR;
  const deliveryFeePKR = isFreeDelivery ? 0 : storeConfig.standardDeliveryFeePKR;
  const totalPKR = subtotalPKR + deliveryFeePKR;

  const pakistaniCities = [
    'Karachi',
    'Lahore',
    'Islamabad',
    'Rawalpindi',
    'Faisalabad',
    'Multan',
    'Peshawar',
    'Quetta',
    'Sialkot',
    'Gujranwala',
    'Hyderabad',
    'Sukkur',
    'Bahawalpur',
    'Sargodha',
    'Overseas (UK / USA / UAE / Canada)'
  ];

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName || !phone || !address) {
      alert('Please fill in your name, contact phone, and delivery address.');
      return;
    }

    if (paymentMethod === 'Card') {
      setIsProcessing(true);
      setTimeout(() => {
        setIsProcessing(false);
        setStep('otp');
      }, 900);
      return;
    }

    finalizeOrder();
  };

  const finalizeOrder = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const orderItems = cart.map((item) => ({
        productId: item.product.id,
        productTitle: item.product.title,
        productCode: item.product.code,
        brand: item.product.brand,
        price: item.product.price,
        quantity: item.quantity,
        image: item.product.image,
        pieces: item.product.pieces
      }));

      const newOrder = createOrder({
        customerName,
        phone,
        email: email || `${phone.replace(/[^0-9]/g, '')}@customer.karachibrands.pk`,
        address,
        city,
        postalCode,
        notes: walletTransactionId ? `Trx ID: ${walletTransactionId}. ${notes}` : notes,
        items: orderItems,
        subtotal: subtotalPKR,
        shippingFee: deliveryFeePKR,
        discount: 0,
        total: totalPKR,
        paymentMethod,
        paymentStatus: paymentMethod === 'COD' ? 'Pending' : 'Paid',
        orderStatus: 'Pending'
      });

      setCreatedOrder(newOrder);
      setIsProcessing(false);
      setStep('success');
    }, 700);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    finalizeOrder();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        className="relative bg-white rounded-xl shadow-2xl max-w-3xl w-full overflow-hidden border border-neutral-200"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="px-6 py-4 bg-neutral-900 text-white flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <h2 className="font-heading text-lg font-bold">
              {step === 'success' ? 'Order Confirmed' : 'Karachi Brands Secure Checkout'}
            </h2>
          </div>
          <button
            onClick={() => setCheckoutOpen(false)}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP 1: Main Checkout Form */}
        {step === 'form' && (
          <form onSubmit={handleSubmitOrder} className="p-6 overflow-y-auto max-h-[82vh]">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Left Column: Customer & Delivery Information */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider pb-1 border-b border-neutral-200 flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-amber-600" />
                  <span>1. Delivery Destination</span>
                </h3>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Customer Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Fatima Khan"
                    className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Phone / WhatsApp *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="0300-1234567"
                      className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@email.com"
                      className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      City *
                    </label>
                    <select
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500 font-medium"
                    >
                      {pakistaniCities.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Area / Postal Code
                    </label>
                    <input
                      type="text"
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value)}
                      placeholder="e.g. DHA Phase 6 / 75500"
                      className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Street Address & House / Apartment # *
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Complete residential or office delivery address"
                    className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Rider Instructions (Optional)
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="e.g. Call before delivery, ring bell twice"
                    className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Right Column: Payment Method with Prominent COD Option */}
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-1 border-b border-neutral-200">
                  <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Banknote className="w-4 h-4 text-emerald-600" />
                    <span>2. Select Payment Method</span>
                  </h3>
                  <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    COD Available
                  </span>
                </div>

                {/* Option 1: Cash on Delivery (COD) - Highlighted */}
                <div className="space-y-2">
                  <label
                    onClick={() => setPaymentMethod('COD')}
                    className={`block p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                      paymentMethod === 'COD'
                        ? 'border-emerald-600 bg-emerald-50/60 shadow-sm ring-1 ring-emerald-500/30'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="radio"
                        name="payment_choice"
                        value="COD"
                        checked={paymentMethod === 'COD'}
                        onChange={() => setPaymentMethod('COD')}
                        className="mt-1 text-emerald-600 focus:ring-emerald-500 h-4 w-4"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-neutral-900 flex items-center gap-1.5">
                            <Banknote className="w-4 h-4 text-emerald-600" />
                            Cash on Delivery (COD)
                          </span>
                          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-200/80 px-2 py-0.5 rounded-full">
                            Pay at Doorstep
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-600 mt-1">
                          Zero advance payment required. Inspect parcel seal and pay courier rider in cash upon unstitched suit delivery.
                        </p>
                        
                        {paymentMethod === 'COD' && (
                          <div className="mt-2.5 pt-2 border-t border-emerald-200/80 flex items-center gap-1.5 text-[11px] text-emerald-800 font-semibold">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>Cash on Delivery active for {city} via TCS Express Courier.</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </label>

                  {/* Option 2: Credit / Debit Card */}
                  <label
                    onClick={() => setPaymentMethod('Card')}
                    className={`block p-3 rounded-lg border cursor-pointer transition-all ${
                      paymentMethod === 'Card'
                        ? 'border-amber-600 bg-amber-50/50 shadow-xs'
                        : 'border-neutral-200 hover:bg-neutral-50 bg-white'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="radio"
                        name="payment_choice"
                        value="Card"
                        checked={paymentMethod === 'Card'}
                        onChange={() => setPaymentMethod('Card')}
                        className="mt-0.5 text-amber-600 focus:ring-amber-500"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-neutral-900 flex items-center gap-1.5">
                            <CreditCard className="w-4 h-4 text-neutral-700" />
                            Credit / Debit Card (Visa / Mastercard)
                          </span>
                          <span className="text-[10px] text-neutral-500 font-medium">
                            3D Secure
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-500 mt-0.5">
                          Instant card authorization with OTP verification.
                        </p>
                      </div>
                    </div>
                  </label>

                  {/* Card Fields */}
                  {paymentMethod === 'Card' && (
                    <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200 space-y-2 text-xs">
                      <div>
                        <label className="block text-[11px] font-semibold text-neutral-700 mb-1">Cardholder Name</label>
                        <input
                          type="text"
                          required
                          value={cardName}
                          onChange={(e) => setCardName(e.target.value)}
                          placeholder="Name on card"
                          className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-neutral-700 mb-1">Card Number</label>
                        <input
                          type="text"
                          required
                          maxLength={19}
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          placeholder="4242 •••• •••• 4242"
                          className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded text-xs font-mono"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] font-semibold text-neutral-700 mb-1">Expiry (MM/YY)</label>
                          <input
                            type="text"
                            required
                            maxLength={5}
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            placeholder="12/28"
                            className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded text-xs font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-neutral-700 mb-1">CVV</label>
                          <input
                            type="password"
                            required
                            maxLength={4}
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value)}
                            placeholder="•••"
                            className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded text-xs font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Option 3: JazzCash / EasyPaisa / Bank Transfer */}
                  <label
                    onClick={() => setPaymentMethod('JazzCash')}
                    className={`block p-3 rounded-lg border cursor-pointer transition-all ${
                      paymentMethod === 'JazzCash'
                        ? 'border-amber-600 bg-amber-50/50 shadow-xs'
                        : 'border-neutral-200 hover:bg-neutral-50 bg-white'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="radio"
                        name="payment_choice"
                        value="JazzCash"
                        checked={paymentMethod === 'JazzCash'}
                        onChange={() => setPaymentMethod('JazzCash')}
                        className="mt-0.5 text-amber-600 focus:ring-amber-500"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-neutral-900 flex items-center gap-1.5">
                            <Smartphone className="w-4 h-4 text-neutral-700" />
                            JazzCash / EasyPaisa / Online Bank
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-500 mt-0.5">
                          Transfer directly to Karachi Brands official merchant account.
                        </p>
                      </div>
                    </div>
                  </label>

                  {/* Bank info */}
                  {paymentMethod === 'JazzCash' && (
                    <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200 text-xs space-y-2">
                      <div className="bg-white p-2.5 rounded border border-neutral-200/80 space-y-1">
                        <div className="text-[11px] font-bold text-amber-800">Direct Account Credentials:</div>
                        <div className="text-[11px] text-neutral-700"><strong>JazzCash / EasyPaisa:</strong> 0300-2426377 (Title: Karachi Brands)</div>
                        <div className="text-[11px] text-neutral-700"><strong>Meezan Bank IBAN:</strong> PK44MEZN00010928374901 (Title: Karachi Brands Pvt)</div>
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-neutral-700 mb-1">Transaction Ref ID</label>
                        <input
                          type="text"
                          value={walletTransactionId}
                          onChange={(e) => setWalletTransactionId(e.target.value)}
                          placeholder="e.g. TRX-998811 or sender number"
                          className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded text-xs font-mono"
                        />
                      </div>
                    </div>
                  )}

                </div>

                {/* Payable Summary */}
                <div className="bg-neutral-50 rounded-lg p-3.5 border border-neutral-200 text-xs space-y-1.5">
                  <div className="flex justify-between text-neutral-600">
                    <span>Order Subtotal ({cart.reduce((a, b) => a + b.quantity, 0)} unstitched suits)</span>
                    <span className="font-semibold text-neutral-900 tabular-nums">{formatPrice(subtotalPKR)}</span>
                  </div>
                  <div className="flex justify-between text-neutral-600">
                    <span>Courier Delivery</span>
                    <span className="font-semibold tabular-nums">
                      {deliveryFeePKR === 0 ? <span className="text-emerald-700 font-bold">FREE</span> : formatPrice(deliveryFeePKR)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-neutral-900 pt-1.5 border-t border-neutral-200">
                    <span>Total {paymentMethod === 'COD' ? 'Payable on Delivery' : 'Amount'}</span>
                    <span className="text-base text-amber-800 tabular-nums">{formatPrice(totalPKR)}</span>
                  </div>
                </div>

                {/* Place Order CTA */}
                <button
                  type="submit"
                  disabled={isProcessing}
                  className={`w-full py-3 px-4 text-white font-bold text-xs sm:text-sm rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                    paymentMethod === 'COD'
                      ? 'bg-emerald-700 hover:bg-emerald-600'
                      : 'bg-neutral-900 hover:bg-neutral-800'
                  }`}
                >
                  {paymentMethod === 'COD' ? (
                    <>
                      <Banknote className="w-4 h-4 text-white" />
                      <span>{isProcessing ? 'Confirming Order...' : `Confirm Cash on Delivery Order · ${formatPrice(totalPKR)}`}</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4 text-amber-400" />
                      <span>{isProcessing ? 'Authorizing Payment...' : `Place Order · ${formatPrice(totalPKR)}`}</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          </form>
        )}

        {/* STEP 2: Card OTP Verification */}
        {step === 'otp' && (
          <div className="p-8 max-w-md mx-auto text-center">
            <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-700">
              <ShieldCheck className="w-6 h-6" />
            </div>

            <h3 className="font-heading text-lg font-bold text-neutral-900 mb-1">
              3D Secure Authentication
            </h3>
            <p className="text-xs text-neutral-500 mb-6">
              A one-time verification code has been sent to your registered mobile phone.
            </p>

            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div>
                <input
                  type="text"
                  maxLength={6}
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="Enter 6-digit OTP (e.g. 786012)"
                  className="w-full px-4 py-2.5 text-center text-lg tracking-widest font-mono font-bold bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                  autoFocus
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('form')}
                  className="w-1/3 py-2.5 px-3 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-semibold rounded-lg cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-2/3 py-2.5 px-4 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold rounded-lg cursor-pointer"
                >
                  {isProcessing ? 'Verifying...' : 'Authorize Payment'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* STEP 3: Order Confirmation */}
        {step === 'success' && createdOrder && (
          <div className="p-6 sm:p-8 overflow-y-auto max-h-[82vh]">
            <div className="text-center mb-6">
              <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3 text-emerald-600">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="font-heading text-2xl font-bold text-neutral-900">
                Order Confirmed Successfully!
              </h2>
              <p className="text-xs text-neutral-600 mt-1">
                {createdOrder.paymentMethod === 'COD' 
                  ? 'Your Cash on Delivery (COD) order has been booked. You will pay cash to the courier upon unstitched suit delivery.'
                  : 'Your payment was authorized and your unstitched suits are being packed for delivery.'}
              </p>
              
              <div className="mt-3 inline-block bg-neutral-100 border border-neutral-200 px-4 py-1.5 rounded-full text-xs font-mono font-bold text-neutral-800">
                Tracking Number: {createdOrder.orderNumber}
              </div>
            </div>

            {/* Printable Invoice */}
            <div className="bg-neutral-50 rounded-xl p-5 border border-neutral-200 text-xs space-y-4 mb-6">
              <div className="flex justify-between items-start pb-3 border-b border-neutral-200">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg overflow-hidden border border-neutral-300 bg-neutral-900 shrink-0">
                    <img
                      src={storeConfig.logoUrl || '/assets/aistudio/Gemini_Generated_Image_l5ybrzl5ybrzl5yb_6cf03367.jpg'}
                      alt="Karachi Brands Logo"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-neutral-900 text-sm">{storeConfig.brandName}</h4>
                    <p className="text-[11px] text-neutral-500">Shop no 3, street no 3 Ghuman Colony, Kadlathi Mord near toll plaza Sheikhupura</p>
                    <p className="text-[11px] text-neutral-600 font-mono">WhatsApp: +923219680442 / +923014205395 · karachiibrands@gmail.com</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-neutral-900">{createdOrder.orderNumber}</div>
                  <div className="text-[11px] font-semibold text-emerald-700 uppercase">
                    Method: {createdOrder.paymentMethod} ({createdOrder.paymentMethod === 'COD' ? 'Pay upon delivery' : createdOrder.paymentStatus})
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pb-3 border-b border-neutral-200 text-[11px]">
                <div>
                  <span className="text-neutral-500 font-semibold block uppercase">Ship To:</span>
                  <div className="font-bold text-neutral-800">{createdOrder.customerName}</div>
                  <div className="text-neutral-600">{createdOrder.address}</div>
                  <div className="text-neutral-600">{createdOrder.city} {createdOrder.postalCode}</div>
                  <div className="text-neutral-600">Phone: {createdOrder.phone}</div>
                </div>
                <div>
                  <span className="text-neutral-500 font-semibold block uppercase">Dispatch Details:</span>
                  <div className="font-bold text-neutral-800">{createdOrder.courierName}</div>
                  <div className="text-neutral-600 font-mono text-[10px]">AWB: {createdOrder.trackingNumber}</div>
                  <div className="text-emerald-700 mt-1 font-semibold">Estimated: 2-3 Working Days</div>
                </div>
              </div>

              <div>
                <span className="text-neutral-500 font-semibold block uppercase mb-2">Suits in Parcel:</span>
                <div className="divide-y divide-neutral-200/80">
                  {createdOrder.items.map((it, idx) => (
                    <div key={idx} className="py-2 flex items-center justify-between text-[11px]">
                      <div>
                        <span className="font-bold text-neutral-900">{it.brand}</span> - {it.productTitle}
                        <span className="text-neutral-500 block">Code: {it.productCode} ({it.pieces}) × {it.quantity}</span>
                      </div>
                      <div className="font-bold text-neutral-900 tabular-nums">
                        {formatPrice(it.price * it.quantity)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 border-t border-neutral-200 space-y-1 text-right text-[11px]">
                <div className="text-neutral-600">
                  Subtotal: <span className="font-semibold text-neutral-800">{formatPrice(createdOrder.subtotal)}</span>
                </div>
                <div className="text-neutral-600">
                  Shipping: <span className="font-semibold text-neutral-800">{createdOrder.shippingFee === 0 ? 'FREE' : formatPrice(createdOrder.shippingFee)}</span>
                </div>
                <div className="text-sm font-bold text-neutral-950 pt-1">
                  Total Payable on Delivery: <span className="text-amber-800">{formatPrice(createdOrder.total)}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3 justify-end">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 border border-neutral-300 hover:bg-neutral-100 text-neutral-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Invoice</span>
              </button>
              <button
                onClick={() => {
                  setCheckoutOpen(false);
                  setStep('form');
                }}
                className="px-5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
