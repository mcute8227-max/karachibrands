export type CategoryType = 
  | 'All Collection'
  | 'New Arrivals'
  | 'Summer Collection'
  | 'Winter Collection'
  | 'Trending Articles'
  | 'Fancy Articles';

export type BrandType = 
  | 'Saya'
  | 'Khaadi'
  | 'Sapphire'
  | 'Nishat'
  | 'Maria B'
  | 'Asim Jofa'
  | 'Sana Safinaz'
  | 'Gul Ahmed';

export type FabricType = 
  | 'Lawn'
  | 'Chiffon'
  | 'Khaddar'
  | 'Pure Silk'
  | 'Velvet'
  | 'Organza'
  | 'Cambric'
  | 'Jacquard';

export type PieceCount = '1-Piece' | '2-Piece' | '3-Piece';

export interface Product {
  id: string;
  code: string;
  title: string;
  brand: BrandType;
  category: CategoryType;
  fabric: FabricType;
  pieces: PieceCount;
  dupattaFabric: string;
  price: number; // in PKR
  originalPrice?: number;
  stock: number;
  rating: number;
  reviewsCount: number;
  isNewArrival: boolean;
  isTrending: boolean;
  isFancy: boolean;
  description: string;
  image: string;
  components: {
    shirt: string;
    dupatta: string;
    trouser: string;
    embroidery: string;
  };
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type OrderStatus = 'Pending' | 'Processing' | 'Dispatched' | 'Delivered' | 'Cancelled';

export interface OrderItem {
  productId: string;
  productTitle: string;
  productCode: string;
  brand: string;
  price: number;
  quantity: number;
  image: string;
  pieces: string;
}

export interface CustomerOrder {
  id: string;
  orderNumber: string;
  createdAt: string;
  customerName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  postalCode?: string;
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  shippingFee: number;
  discount: number;
  total: number;
  paymentMethod: 'COD' | 'Card' | 'JazzCash' | 'EasyPaisa' | 'BankTransfer' | 'WhatsApp';
  paymentStatus: 'Pending' | 'Paid';
  orderStatus: OrderStatus;
  courierName?: string;
  trackingNumber?: string;
}

export type CurrencyCode = 'PKR' | 'USD' | 'GBP' | 'AED' | 'SAR' | 'CAD';

export interface CurrencyRate {
  code: CurrencyCode;
  symbol: string;
  rateAgainstPKR: number; // e.g. 1 USD = 280 PKR, so rate = 0.00357
  name: string;
}

export type FontHeadingOption = 
  | 'Playfair Display'
  | 'Cinzel'
  | 'Cormorant Garamond'
  | 'Outfit'
  | 'Montserrat';

export type FontBodyOption = 
  | 'Plus Jakarta Sans'
  | 'Outfit'
  | 'Montserrat';

export type FontSizeScale = 'compact' | 'standard' | 'large';
export type HeadingSizeScale = 'normal' | 'large' | 'xlarge';

export interface StoreConfig {
  // Brand identity
  brandName: string;
  tagline: string;
  logoUrl?: string;
  logoSize: 'small' | 'medium' | 'large';
  secondaryPhone?: string;
  whatsappNumber: string;
  supportEmail: string;
  storeAddress: string;

  // Header settings
  showAnnouncement: boolean;
  announcementText: string;
  announcementBgColor: string;
  announcementTextColor: string;
  headerBgColor: string;
  headerTextColor: string;
  navLinks: string[];

  // Footer settings
  footerBgColor: string;
  footerTextColor: string;
  copyrightText: string;
  showFooterCollections: boolean;
  showFooterBrands: boolean;
  showFooterContact: boolean;
  showFooterPaymentLogos: boolean;

  // Colors & Theme
  primaryColor: string;
  accentColor: string;
  bodyBgColor: string;
  textColor: string;
  themePreset: string;

  // Typography
  fontHeading: FontHeadingOption;
  fontBody: FontBodyOption;
  headingFontSizeScale: HeadingSizeScale;
  bodyFontSizeScale: FontSizeScale;
  headingFontWeight: 'normal' | 'semibold' | 'bold';

  // Hero Campaign Section
  bannerHeadline: string;
  bannerSubheadline: string;
  bannerImageUrl: string;
  bannerPrimaryBtnText: string;
  bannerSecondaryBtnText: string;
  showTrustPillars: boolean;
  pillar1Text: string;
  pillar2Text: string;
  pillar3Text: string;
  pillar4Text: string;

  // COD & Delivery policy
  enableCOD: boolean;
  codBadgeText: string;
  freeDeliveryThresholdPKR: number;
  standardDeliveryFeePKR: number;
}
